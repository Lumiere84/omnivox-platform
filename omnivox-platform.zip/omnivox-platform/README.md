# OmniVox Platform

English for Spanish speakers and Spanish for English speakers: 3-minute lessons, server-graded
exercises, XP, streaks, hearts, weekly leagues, spaced-repetition review and an AI tutor that
explains in the learner's own language. Add a language pair by dropping a `course_*.json` file into
`backend/app/seed/`.

- **Backend:** Python 3.12, FastAPI, SQLAlchemy 2 (async), PostgreSQL, Redis, Alembic
- **Web app:** dependency-free SPA in `web/` (served by the API, or by a CDN at scale)
- **Live demo:** `python tools/build_demo.py` → `dist/omnivox-live-demo.html` (runs fully in the browser)
- **Architecture, schema, API and scaling plan:** [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)

## Run it

**Everything with Docker (recommended)**

```bash
docker compose -f infra/docker-compose.yml up --build
# open http://localhost:8000   (API docs: http://localhost:8000/docs)
```

**Without Docker**

```bash
cd backend
python -m venv .venv && . .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env                              # set DATABASE_URL, REDIS_URL, JWT_SECRET
alembic upgrade head
python -m app.seed                                # loads both starter courses
uvicorn app.main:app --reload
```

Create an admin for the content studio API:

```bash
ADMIN_PASSWORD='choose-a-strong-one' python -m app.seed --admin-email you@example.com
```

## Deploy to Render

New → **Blueprint** → choose this repository. `render.yaml` creates the web service, a PostgreSQL
database and a Key Value (Redis) store, and generates `JWT_SECRET`. Optional: add `ANTHROPIC_API_KEY`
in the Render dashboard to switch the tutor from the built-in explainer to Claude.

## Test

```bash
cd backend
pytest -q                                          # SQLite + fakeredis, no services needed
TEST_DATABASE_URL=postgresql+psycopg://postgres@localhost/omnivox_test \
TEST_REDIS_URL=redis://localhost:6379/1 pytest -q   # same suite on real PostgreSQL + Redis
```

## Configuration

| Variable | Default | Notes |
|---|---|---|
| `ENV` | `development` | `production` enables HSTS, hides `/docs`, and refuses unsafe settings |
| `DATABASE_URL` | SQLite file | `postgres://` URLs are converted to `postgresql+asyncpg://` |
| `DATABASE_READ_URL` | none | Optional read replica |
| `REDIS_URL` | `redis://localhost:6379/0` | Cache, rate limits, leagues, jobs (fails open) |
| `JWT_SECRET` | dev value | **Required in production**, 32+ random characters |
| `ALLOWED_HOSTS` / `CORS_ORIGINS` | `*` / localhost | Comma-separated |
| `ANTHROPIC_API_KEY`, `TUTOR_MODEL` | none / `claude-haiku-5-5` | AI tutor |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_PREMIUM` | none | Premium subscriptions |
| `JOBS_ENABLED` | `true` | Set `false` if no worker runs |
| `METRICS_TOKEN` | none | Protects `/metrics` |
