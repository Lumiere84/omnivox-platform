# OmniVox: System Architecture

OmniVox teaches **English to Spanish speakers** and **Spanish to English speakers** with short lessons,
server-graded exercises, XP and streaks, weekly leagues, spaced-repetition review and an AI tutor that
explains in the learner's own language. Every course carries its language pair (`from_lang` → `to_lang`),
so a new pair (Portuguese, French…) is a content file, not new code.
This document covers the MVP as built and how it scales to millions of learners.

## 1. Product scope (MVP)

| Area | What ships |
|---|---|
| Accounts | Email + password, JWT access tokens (15 min), rotating refresh tokens with theft detection, account deletion |
| Courses | **Inglés Esencial A1** (es → en, 9 lessons) and **Spanish Essentials A1** (en → es, 9 lessons). Learners choose at sign-up and can switch any time |
| Learning | Course > Unit > Lesson > Exercise; 5 exercise kinds (multiple choice, fill blank, translate, listen & type, word bank) |
| Grading | Server-side only. Answers never reach the client. Normalises case, punctuation (including ¿ ¡), curly quotes and contractions; forgives one small typo; accepts missing Spanish accents on typed answers but shows where they go (choices must match exactly) |
| Motivation | XP ledger, streaks in the learner's own time zone (with streak freezes), daily goal, hearts (free tier), weekly league |
| Retention | SM-2 spaced repetition: words you get right join your review deck |
| AI tutor | Claude (when `ANTHROPIC_API_KEY` is set) with a built-in fallback. Explains in the learner's language (Spanish or English) with examples in the target language. Rate-limited per user and plan |
| Revenue | Freemium. Stripe Checkout + signed, idempotent webhooks; Premium = unlimited hearts, bonus lessons, 5× tutor, streak freezes |
| Content studio | Admin API to create courses, units, lessons, exercises and vocabulary; publishing bumps a content version that invalidates caches |
| Operations | Structured JSON logs with request IDs, Prometheus metrics, liveness/readiness probes, security headers, rate limits |

## 2. System architecture

```mermaid
flowchart LR
  subgraph Clients
    W[Web app - SPA]
    M[iOS / Android - React Native]
  end
  CDN[CDN + WAF<br/>static app, audio, images]
  LB[Load balancer<br/>TLS, HTTP/2]
  subgraph API[Stateless API tier - FastAPI on Kubernetes, autoscaled]
    A1[api pod]
    A2[api pod]
    A3[api pod ...]
  end
  subgraph Data
    PG[(PostgreSQL primary)]
    RR[(Read replicas)]
    R[(Redis cluster<br/>cache, rate limits,<br/>leagues, job queue)]
    S3[(Object storage<br/>TTS audio, exports)]
  end
  WK[Worker pods<br/>emails, analytics fan-out,<br/>TTS pre-generation]
  EXT1[Claude API - tutor]
  EXT2[Stripe - billing]
  WH[(Warehouse<br/>BigQuery / Snowflake)]

  W --> CDN --> LB
  M --> LB
  LB --> A1 & A2 & A3
  A1 & A2 & A3 --> PG
  A1 & A2 & A3 --> RR
  A1 & A2 & A3 --> R
  A1 & A2 & A3 --> EXT1
  A1 & A2 & A3 --> EXT2
  EXT2 -- signed webhooks --> LB
  R --> WK
  WK --> PG
  WK --> S3
  WK --> WH
  S3 --> CDN
```

**Request path for the core loop.** Open lesson (content served from Redis cache, keyed by course version)
→ start attempt (checks hearts) → answer each exercise (graded on the server, one row per answer,
hearts adjusted under a row lock) → complete (idempotent; awards XP once through a unique ledger key,
advances the streak in the learner's time zone, updates the league sorted set, enqueues analytics).

### Design decisions

| Decision | Why |
|---|---|
| **Modular monolith** (one FastAPI service, clear modules) | Fastest path to market and simplest to operate. Modules (auth, content, learning, social, billing) have clean boundaries and can be split into services when a team or a load profile demands it. |
| **Async Python** (FastAPI + SQLAlchemy 2 async + asyncpg) | High concurrency per pod for an I/O-bound API; typed request/response models generate the OpenAPI contract the mobile apps build against. |
| **PostgreSQL as source of truth** | Relational integrity for progress and billing; row locks make XP and hearts race-free; JSONB for flexible exercise payloads. |
| **Redis for hot paths** | Content cache, fixed-window rate limits, weekly leagues (sorted sets: O(log N) writes and top-K reads) and a lightweight job queue. Every Redis use fails open, so a cache outage degrades features rather than taking the API down. |
| **Append-only XP ledger** | `xp_events` is the audit trail and the source for analytics; `user_stats` is a fast per-user rollup. A unique key on `(source, ref_id)` makes every award idempotent. |
| **Server-side grading** | Answers are never sent to clients, so scores and leagues cannot be cheated by reading the network response. |
| **Opaque, rotating refresh tokens** | Stored as SHA-256 hashes. Re-use of a rotated token revokes the whole session family (stolen-token detection). |
| **One client, two back ends** | The web app calls `api(method, path)`. In production that is the FastAPI server; in the live demo it is an in-browser engine that implements the same endpoints and rules. |

## 3. File structure

```
omnivox-platform/
├── backend/
│   ├── app/
│   │   ├── main.py              # app factory, middleware (request ID, security headers, metrics), routers
│   │   ├── core/                # config, security (scrypt, JWT), errors, logging, Redis, rate limiting
│   │   ├── db/session.py        # async engines: primary + optional read replica
│   │   ├── models/              # SQLAlchemy models: user, content, progress, billing
│   │   ├── schemas/             # Pydantic request/response models (the API contract)
│   │   ├── services/            # grading, gamification (XP/streak/hearts), SM-2, leaderboard, cache, tutor, billing
│   │   ├── api/deps.py          # auth + DB dependencies, RBAC
│   │   ├── api/v1/              # auth, me, courses, lessons, review, social (league + tutor), billing, admin, health
│   │   ├── workers/             # Redis job queue + handlers (python -m app.workers)
│   │   └── seed/                # course_en_a1.json (es→en), course_es_a1.json (en→es) + seeding CLI
│   ├── alembic/                 # migrations (0001 initial schema: 16 tables)
│   ├── tests/                   # 33 tests: unit, API flows (both courses), concurrency, webhooks, RBAC
│   ├── Dockerfile               # non-root image; migrates, seeds, serves
│   └── requirements*.txt
├── web/                         # SPA: index.html, css/app.css, js/{i18n,api,engine,app}.js
├── tools/build_demo.py          # bundles web + engine + course into one self-contained demo page
├── infra/
│   ├── docker-compose.yml       # local stack: Postgres, Redis, API, worker
│   └── k8s/                     # Deployment, HPA, PDB, migration Job, worker
├── render.yaml                  # one-click Render deploy (web + Postgres + Key Value)
└── .github/workflows/ci.yml     # lint, tests on SQLite and on real Postgres + Redis, migration check
```

## 4. Database schema (PostgreSQL)

16 tables. UUID primary keys, `timestamptz` everywhere, named constraints for deterministic migrations.

| Table | Purpose | Key columns / constraints |
|---|---|---|
| `users` | Accounts | `email` UNIQUE (lower-cased), `password_hash` (scrypt), `native_lang`, `target_lang`, `timezone`, `role` (learner/admin), `plan` (free/premium), `daily_goal_xp` |
| `refresh_tokens` | Sessions | `token_hash` UNIQUE, `family_id`, `expires_at`, `revoked_at`; index on `user_id` |
| `courses` | Course catalogue | `slug` UNIQUE, `from_lang`, `to_lang`, `cefr_level`, `is_published`, `content_version` |
| `units` | Course sections | FK course; UNIQUE (`course_id`, `position`) |
| `lessons` | Lessons | FK unit; UNIQUE (`unit_id`, `position`); `xp_reward`, `is_premium` |
| `exercises` | Exercises | FK lesson; `kind`; `payload` JSONB (client-safe); `answers` JSONB (server-only); `explanation`; FK `vocab_id` |
| `vocab_items` | Vocabulary | UNIQUE (`course_id`, `term`); `translation`, `example`, `audio_url` |
| `enrollments` | Learner ↔ course | PK (`user_id`, `course_id`) |
| `lesson_attempts` | One play of a lesson | `completed_at`, `correct`, `total`, `xp_earned`; indexes (`user_id`, `lesson_id`), (`user_id`, `completed_at`) |
| `exercise_answers` | Every answer | UNIQUE (`attempt_id`, `exercise_id`); `given`, `is_correct` |
| `user_stats` | Hot per-user rollup | PK `user_id`; `total_xp`, streak fields, `streak_freezes`, `hearts`, `hearts_updated_at`, `lessons_completed` |
| `xp_events` | Append-only XP ledger | UNIQUE (`source`, `ref_id`) = idempotency; index (`user_id`, `created_at`) |
| `review_cards` | SM-2 state | PK (`user_id`, `vocab_id`); `ease`, `interval_days`, `repetitions`, `lapses`, `due_at`; index (`user_id`, `due_at`) |
| `tutor_messages` | Tutor transcript | index (`user_id`, `created_at`); `provider` |
| `subscriptions` | Billing state | `user_id` UNIQUE, `subscription_ref` UNIQUE, `status`, `current_period_end` |
| `processed_webhooks` | Webhook idempotency | PK `event_id` |

All user-owned rows cascade on user deletion (right to erasure).

## 5. API endpoints (`/api/v1`)

Errors always look like `{"error": {"code", "message", "request_id"}}`. Interactive docs at `/docs` (disabled in production).

| Method | Path | Access | Purpose |
|---|---|---|---|
| POST | `/auth/register` | public, rate-limited | Create account, returns tokens |
| POST | `/auth/login` | public, rate-limited per IP and per account | Sign in (constant-time on unknown emails) |
| POST | `/auth/refresh` | refresh token | Rotate tokens; re-use revokes the session family |
| POST | `/auth/logout` | user | Revoke the session family |
| GET / PATCH / DELETE | `/me` | user | Profile; update name, time zone, daily goal; delete account |
| GET | `/me/stats` | user | XP (total and today), streak, hearts, lessons completed |
| GET | `/courses` | public | Published courses (cached) |
| POST | `/courses/{slug}/enroll` | user | Enroll |
| GET | `/courses/{slug}/path` | user | Units and lessons with state: completed / available / locked / premium |
| GET | `/lessons/{id}` | user | Lesson with exercises (no answers) |
| POST | `/lessons/{id}/attempts` | user | Start an attempt (checks hearts and Premium) |
| POST | `/attempts/{id}/answers` | user | Grade one answer; returns correct answer, explanation, hearts |
| POST | `/attempts/{id}/complete` | user | Finish; awards XP once, advances streak, updates league |
| GET | `/review/due` | user | Review cards due now |
| POST | `/review/{vocab_id}` | user | Grade recall 0–5; reschedules with SM-2 |
| GET | `/leaderboard/weekly?course=` | user | Weekly league top-N plus your rank |
| POST | `/tutor/ask` | user, rate-limited by plan | Ask the AI tutor (optionally about an exercise) |
| POST | `/billing/checkout` | user | Stripe Checkout URL for Premium |
| GET | `/billing/subscription` | user | Plan and subscription status |
| POST | `/billing/webhook` | Stripe signature | Applies subscription events once |
| POST | `/admin/courses`, `/admin/units`, `/admin/lessons`, `/admin/exercises`, `/admin/vocab` | admin | Content studio |
| POST | `/admin/courses/{id}/publish` | admin | Publish or unpublish (bumps cache version) |
| GET | `/admin/metrics` | admin | Users, Premium users, lessons completed |
| GET | `/healthz`, `/readyz`, `/metrics` | ops | Liveness, readiness (DB + Redis), Prometheus (token-protected when set) |

## 6. UI architecture

| Layer | Web (built) | Mobile (next) |
|---|---|---|
| Shell | Sticky stat bar (streak, XP, hearts), hash router: `#learn`, `#review`, `#league` | React Native + Expo, tab navigator |
| Screens | Sign-up/in · Learning path · Lesson player · Lesson complete · Review flashcards · League · Tutor drawer · Premium sheet | Same screens, shared API contract |
| Data | `api.js`: one `api(method, path, body)` function; silent token refresh on 401; every call shown in the live API log | Generated TypeScript client from OpenAPI; React Query cache |
| Lesson player | Renders by `kind`; keyboard shortcuts (1–4, Enter); speech via browser TTS in the course's target language (female US English or Mexican Spanish voice when available); confetti + count-up on completion | Pre-generated TTS audio from the CDN; offline lesson packs |
| Theming | Design tokens in CSS custom properties: navy night, violet + cyan voice waves, amber rewards | Same tokens exported to the app theme |
| Language | Sign-up asks "What do you want to learn?"; the interface follows the learner's own language (toggle available); a course switcher (ES → EN / EN → ES) sits in the top bar | Device locale |
| Accessibility | Visible focus rings, ARIA roles on progress and dialogs, reduced-motion support, 400 px phone layout | Dynamic type, VoiceOver/TalkBack labels |

## 7. Security

- Passwords: scrypt (N=2^14, r=8), automatic rehash when the cost changes; minimum strength rules.
- Tokens: HS256 JWT access tokens (15 min) with issuer and type checks; refresh tokens are opaque, hashed, rotated and family-revoked on re-use.
- Abuse: rate limits on auth (per IP and per account), per user, and on the tutor; request size cap (64 KB).
- Data: server-side grading; ownership checks on every attempt; RBAC for admin; parameterised SQL only (ORM).
- Transport and browser: HSTS (production), strict CSP (`script-src 'self'`, `frame-ancestors 'none'`), `nosniff`, `X-Frame-Options: DENY`, referrer and permissions policies; trusted-host check.
- Billing: webhook HMAC verification with timestamp tolerance; idempotent event processing.
- Privacy: account deletion cascades; logs carry request IDs, not emails or passwords; production refuses to boot with the development secret, SQLite, or wildcard hosts.

## 8. Scaling to millions

**Planning numbers** for the go-to-market target: 10 M registered learners, 2 M daily active.

| Metric | Estimate |
|---|---|
| API requests | ~80 per active learner per day → 160 M/day ≈ 1,900 req/s average, ~7,500 req/s at the evening peak |
| Answer writes | 2 M × 3 lessons × 6 answers ≈ 36 M rows/day ≈ 420 writes/s average, ~2,000/s peak |
| API pods | ~1,000 req/s per 4-worker pod for these endpoints → 10–15 pods at peak; HPA range 6–120 |
| Storage growth | ~3–4 GB/day of answers + ledger before archiving |

**Phase 1 — Launch (0 → 100 k learners).** One region. Managed PostgreSQL (primary + 1 replica), managed Redis,
6 API pods, 2 workers, CDN for the web app and audio. Everything in this repository as-is.

**Phase 2 — Growth (100 k → 2 M).**
- Route read-heavy endpoints (path, review, league, stats) to read replicas (`DATABASE_READ_URL` is already wired).
- Monthly partitions for `exercise_answers` and `xp_events`; archive partitions older than 90 days to the warehouse.
- PgBouncer in transaction mode in front of PostgreSQL to keep connections flat as pods scale.
- Redis Cluster; leagues become cohorts of 30 learners per division (the motivating format at scale) instead of one global set.
- Pre-generate lesson audio with a neural TTS in workers; serve from the CDN.
- Event stream (Kafka/Kinesis) from the job queue for analytics, experimentation and notifications.

**Phase 3 — Millions (2 M → 20 M+).**
- Multi-region active-passive, then active-active reads; learners pinned to a home region.
- Shard learner data by `user_id` (Citus or application-level sharding); content stays global and cache-first.
- Split services along the existing module lines where load differs: content (read-mostly, edge-cached), learning (write-heavy), social, billing, tutor.
- Tutor cost control: smaller model by default, answer caching for common questions, per-plan quotas (already enforced).

**Reliability targets.** 99.9 % monthly availability for the learning loop; p95 latency under 150 ms for lesson and answer calls;
RPO 5 min (PITR backups), RTO 30 min. Alerts on error rate, p95 latency, DB connection saturation, Redis memory and queue depth (all exported as metrics).

## 9. Go-to-market

| Item | Plan |
|---|---|
| Audience | Two-sided: ~500 M native Spanish speakers learning English, and Spanish is the most-studied language among US English speakers. Launch markets: Mexico, Colombia and the US (both directions), then Spain and Argentina |
| Pricing | Free with hearts; Premium $6.99/month or $59.99/year; family plan later |
| Acquisition | TikTok and Instagram short-form lessons, creator partnerships, schools and employers (B2B seats) |
| North-star metric | Weekly learners who finish 3+ lessons |
| Launch checklist | Content for A1–A2 (≈60 lessons), app-store listings, Stripe live keys, analytics dashboard, support inbox, privacy policy (GDPR/LGPD/CCPA) |
