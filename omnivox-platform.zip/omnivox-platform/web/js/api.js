/* API client. One function, api(method, path, body), for the whole app.

   - Production: calls the FastAPI backend, refreshes the access token on 401 and retries once.
   - Live demo:  when window.OMNIVOX_DEMO is set, the same calls are answered by the in-browser
                 engine (engine.js), which mirrors the backend's endpoints and rules.

   Every call is reported to listeners so the UI can show the live API log. */
(function () {
  const PREFIX = "/api/v1";
  const listeners = [];
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (e) {} },
  };
  let access = store.get("ov.access");
  let refresh = store.get("ov.refresh");
  let refreshing = null;

  class ApiError extends Error {
    constructor(status, body) {
      const err = (body && body.error) || {};
      super(err.message || "Request failed");
      this.status = status; this.code = err.code || "error";
    }
  }

  function setTokens(t) {
    access = t ? t.access_token : null; refresh = t ? t.refresh_token : null;
    store.set("ov.access", access); store.set("ov.refresh", refresh);
  }

  function emit(entry) { listeners.forEach((fn) => fn(entry)); }

  async function http(method, path, body, retry = true) {
    const headers = { "Content-Type": "application/json" };
    if (access) headers.Authorization = "Bearer " + access;
    const res = await fetch(PREFIX + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
    if (res.status === 401 && retry && refresh && !path.startsWith("/auth/")) {
      refreshing = refreshing || http("POST", "/auth/refresh", { refresh_token: refresh }, false)
        .then(setTokens).catch(() => setTokens(null)).finally(() => { refreshing = null; });
      await refreshing;
      if (access) return http(method, path, body, false);
    }
    const data = res.status === 204 ? null : await res.json().catch(() => null);
    return { status: res.status, data };
  }

  async function api(method, path, body) {
    const started = performance.now();
    let result;
    if (window.OMNIVOX_DEMO && window.OmniEngine) {
      result = await window.OmniEngine.handle(method, PREFIX + path, body);
    } else {
      result = await http(method, path, body);
    }
    emit({ method, path: PREFIX + path, status: result.status, ms: Math.round(performance.now() - started) });
    if (result.status >= 400) throw new ApiError(result.status, result.data);
    if (path === "/auth/login" || path === "/auth/register") setTokens(result.data);
    return result.data;
  }

  window.API = {
    call: api,
    get: (p) => api("GET", p),
    post: (p, b) => api("POST", p, b || {}),
    patch: (p, b) => api("PATCH", p, b),
    onCall(fn) { listeners.push(fn); },
    get signedIn() { return !!access; },
    signOut() { if (refresh && !window.OMNIVOX_DEMO) api("POST", "/auth/logout", { refresh_token: refresh }).catch(() => {}); setTokens(null); },
    ApiError,
  };
})();
