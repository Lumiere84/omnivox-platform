/* Interface strings. Lesson content itself is always English-for-Spanish-speakers. */
(function () {
  const S = {
    es: {
      tagline: "Habla otro idioma con <em>confianza</em>.",
      pitch: "Lecciones de 3 minutos, un tutor con IA que te explica en tu idioma, rachas diarias y ligas semanales. Inglés para hispanohablantes y español para angloparlantes.",
      signup: "Crear cuenta", login: "Entrar", name: "Tu nombre", email: "Correo", password: "Contraseña",
      pwHint: "10+ caracteres, una mayúscula y un número", start: "Empezar gratis", welcomeBack: "Continuar",
      demoNote: "Demo en vivo: tus datos se guardan solo en este navegador.",
      learn: "Aprender", review: "Repaso", league: "Liga",
      dailyGoal: "Meta diaria", ofGoal: "de {n} XP hoy", goalMet: "¡Meta cumplida!",
      weeklyLeague: "Liga semanal", resetsIn: "Se reinicia el lunes", yourRank: "Tu puesto",
      start_: "EMPEZAR", locked: "Completa la lección anterior para desbloquear",
      premiumTitle: "OmniVox Premium", premiumPitch: "Corazones ilimitados, lecciones extra, 5× tutor IA y protector de racha.",
      goPremium: "Probar Premium", perMonth: "/mes", activate: "Activar Premium (demo)", notNow: "Ahora no", premiumOn: "Premium activado. ¡Disfruta!",
      p1: "Corazones ilimitados", p2: "Lecciones Premium extra", p3: "5× preguntas al tutor IA", p4: "Protector de racha",
      check: "Comprobar", continue_: "Continuar", skip: "Saltar",
      correct: "¡Correcto!", almost: "¡Casi! Revisa la ortografía", wrong: "Respuesta correcta:",
      askTutor: "Pregúntale al tutor",
      kinds: { multiple_choice: "Elige la respuesta", fill_blank: "Completa la frase", translate: "Traduce", listen_type: "Escucha y escribe", word_bank: "Ordena las palabras" },
      typeHere: "Escribe en inglés…", tapWords: "Toca las palabras en orden",
      lessonDone: "¡Lección completada!", xpEarned: "XP", accuracy: "Precisión", streak: "Racha",
      streakUp: "¡Tu racha sube a {n} {d}!", backHome: "Volver al camino",
      outOfHearts: "Te quedaste sin corazones", heartsRefill: "Se recargan 1 cada 30 min, o pásate a Premium.",
      reviewTitle: "Repaso inteligente", reviewSub: "Las palabras vuelven justo cuando estás por olvidarlas.",
      tapToFlip: "Toca para ver la traducción", again: "Otra vez", hard: "Difícil", good: "Bien", easy: "Fácil",
      nothingDue: "¡Todo al día!", nothingDueSub: "Completa lecciones para sumar palabras a tu mazo.",
      tutor: "Tutor OmniVox", tutorHi: "¡Hola! Soy tu tutor. Pregúntame lo que quieras sobre el idioma que estás aprendiendo.",
      ask: "Pregunta…", send: "Enviar", left: "{n} preguntas restantes esta hora",
      s1: "¿Cuándo uso do o does?", s2: "¿Diferencia entre in, on y at?", s3: "¿Cómo se forma el pasado?",
      signOut: "Salir", apiLog: "Llamadas a la API", live: "en vivo",
      exitLesson: "Salir de la lección", needAll: "Responde todos los ejercicios",
      xpToast: "+{n} XP", deck: "en tu mazo", due: "pendientes",
      chooseTitle: "¿Qué quieres aprender?", optEn: "Inglés", optEnSub: "para hispanohablantes", optEs: "Español", optEsSub: "para angloparlantes",
      accentMissed: "¡Correcto! Ojo con los acentos:", switchCourse: "Cambiar de curso",
      t1: "¿Cuándo uso do o does?", t2: "¿Diferencia entre in, on y at?", t3: "¿Cómo se forma el pasado?",
      u1: "When do I use ser or estar?", u2: "Por or para?", u3: "Tú or usted?",
    },
    en: {
      tagline: "Speak a new language with <em>confidence</em>.",
      pitch: "3-minute lessons, an AI tutor that explains in your own language, daily streaks and weekly leagues. Spanish for English speakers and English for Spanish speakers.",
      signup: "Create account", login: "Sign in", name: "Your name", email: "Email", password: "Password",
      pwHint: "10+ characters, one capital letter and a number", start: "Start free", welcomeBack: "Continue",
      demoNote: "Live demo: your data stays in this browser only.",
      learn: "Learn", review: "Review", league: "League",
      dailyGoal: "Daily goal", ofGoal: "of {n} XP today", goalMet: "Goal reached!",
      weeklyLeague: "Weekly league", resetsIn: "Resets Monday", yourRank: "Your rank",
      start_: "START", locked: "Finish the previous lesson to unlock",
      premiumTitle: "OmniVox Premium", premiumPitch: "Unlimited hearts, bonus lessons, 5× AI tutor and streak protection.",
      goPremium: "Try Premium", perMonth: "/mo", activate: "Activate Premium (demo)", notNow: "Not now", premiumOn: "Premium is on. Enjoy!",
      p1: "Unlimited hearts", p2: "Bonus Premium lessons", p3: "5× AI tutor questions", p4: "Streak protection",
      check: "Check", continue_: "Continue", skip: "Skip",
      correct: "Correct!", almost: "Almost! Check your spelling", wrong: "Correct answer:",
      askTutor: "Ask the tutor",
      kinds: { multiple_choice: "Choose the answer", fill_blank: "Fill in the blank", translate: "Translate", listen_type: "Listen and type", word_bank: "Put the words in order" },
      typeHere: "Type in English…", tapWords: "Tap the words in order",
      lessonDone: "Lesson complete!", xpEarned: "XP", accuracy: "Accuracy", streak: "Streak",
      streakUp: "Your streak is now {n} {d}!", backHome: "Back to the path",
      outOfHearts: "You're out of hearts", heartsRefill: "One refills every 30 min, or go Premium.",
      reviewTitle: "Smart review", reviewSub: "Words come back right before you'd forget them.",
      tapToFlip: "Tap to see the translation", again: "Again", hard: "Hard", good: "Good", easy: "Easy",
      nothingDue: "All caught up!", nothingDueSub: "Finish lessons to add words to your deck.",
      tutor: "OmniVox Tutor", tutorHi: "Hi! I'm your tutor. Ask me anything about the language you're learning.",
      ask: "Ask…", send: "Send", left: "{n} questions left this hour",
      s1: "¿Cuándo uso do o does?", s2: "¿Diferencia entre in, on y at?", s3: "¿Cómo se forma el pasado?",
      signOut: "Sign out", apiLog: "API calls", live: "live",
      exitLesson: "Leave lesson", needAll: "Answer every exercise",
      xpToast: "+{n} XP", deck: "in your deck", due: "due",
      chooseTitle: "What do you want to learn?", optEn: "English", optEnSub: "for Spanish speakers", optEs: "Spanish", optEsSub: "for English speakers",
      accentMissed: "Correct! Watch the accents:", switchCourse: "Switch course",
      t1: "¿Cuándo uso do o does?", t2: "¿Diferencia entre in, on y at?", t3: "¿Cómo se forma el pasado?",
      u1: "When do I use ser or estar?", u2: "Por or para?", u3: "Tú or usted?",
    },
  };
  let lang = "es";
  try { lang = localStorage.getItem("ov.lang") || (navigator.language || "es").slice(0, 2); } catch (e) {}
  if (!S[lang]) lang = "es";
  window.I18N = {
    get lang() { return lang; },
    set(l) { lang = S[l] ? l : "es"; try { localStorage.setItem("ov.lang", lang); } catch (e) {} document.documentElement.lang = lang; },
    t(key, vars) {
      const parts = key.split(".");
      let v = S[lang];
      for (const p of parts) v = v && v[p];
      if (v == null) v = key;
      return vars ? String(v).replace(/\{(\w+)\}/g, (_, k) => vars[k]) : v;
    },
  };
})();
