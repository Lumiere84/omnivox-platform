/* OmniVox in-browser engine — powers the live demo with no server.
   Mirrors the FastAPI backend endpoint-for-endpoint (same paths, JSON shapes and rules:
   server-side grading with accent forgiveness, hearts, XP formula, streaks, SM-2 review,
   per-course weekly leagues, bilingual tutor), so the web app runs unchanged against either one.
   State lives in this browser's localStorage. */
(function () {
  const COURSES = window.OMNIVOX_COURSES || [window.OMNIVOX_COURSE];
  const KEY = "ov.demo.v2";
  const CFG = { heartsMax: 5, refillMin: 30, xpPerCorrect: 2, perfectBonus: 5, tutorPerHour: 20 };
  const DAY = 86400000;
  const FREE_TEXT = ["translate", "listen_type", "fill_blank"];

  // ---- content index (ids are stable, derived from course + position) ----
  const lessons = {}; const exercises = {}; const vocab = {}; const courses = {};
  const vid = (ci, term) => `c${ci}-v-` + term.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\W+/g, "-");
  COURSES.forEach((C, ci) => {
    C.vocab.forEach((v) => { vocab[vid(ci, v.term)] = Object.assign({ course: C.slug }, v); });
    const skeleton = C.units.map((u, ui) => ({
      id: `c${ci}-u${ui + 1}`, position: ui + 1, title: u.title, description: u.description,
      lessons: u.lessons.map((l, li) => {
        const id = `c${ci}-l${ui + 1}-${li + 1}`;
        const ex = l.exercises.map((e, ei) => {
          const eid = `${id}-e${ei + 1}`;
          exercises[eid] = Object.assign({ id: eid, lesson_id: id, position: ei + 1, ci }, e);
          return eid;
        });
        lessons[id] = { id, course: C.slug, title: l.title, xp_reward: l.xp_reward, is_premium: !!l.is_premium, exercises: ex };
        return { id, position: li + 1, title: l.title, xp_reward: l.xp_reward, is_premium: !!l.is_premium };
      }),
    }));
    courses[C.slug] = { meta: { id: "c" + ci, slug: C.slug, title: C.title, description: C.description, from_lang: C.from_lang, to_lang: C.to_lang, cefr_level: C.cefr_level }, skeleton };
  });

  // ---- persistence ----
  let db;
  function load() { try { db = JSON.parse(localStorage.getItem(KEY)) || null; } catch (e) { db = null; } if (!db) db = { user: null }; }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) {} }
  load();

  // ---- helpers (ports of app/services/*.py) ----
  const CONTRACTIONS = { "i'm": "i am", "you're": "you are", "he's": "he is", "she's": "she is", "it's": "it is", "we're": "we are", "they're": "they are", "don't": "do not", "doesn't": "does not", "isn't": "is not", "aren't": "are not", "can't": "cannot", "won't": "will not", "i've": "i have", "let's": "let us", "what's": "what is", "that's": "that is" };
  function normalise(t) {
    t = (t || "").normalize("NFKC").toLowerCase().replace(/[‘’`]/g, "'");
    t = t.replace(/[^\p{L}\p{N}\s']/gu, " ").replace(/\s+/g, " ").trim();
    return t.split(" ").map((w) => CONTRACTIONS[w] || w).join(" ");
  }
  const bare = (t) => t.normalize("NFD").replace(/[̀-ͯ]/g, "");
  function similarity(a, b) {
    const m = a.length, n = b.length; if (!m || !n) return 0;
    const d = Array.from({ length: m + 1 }, (_, i) => [i]);
    for (let j = 1; j <= n; j++) d[0][j] = j;
    for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return 1 - d[m][n] / Math.max(m, n);
  }
  function grade(kind, given, accepted) {
    const g = normalise(given);
    for (const a of accepted) if (normalise(a) === g) return { correct: true, typo: false, accent: false, best: a };
    if (!FREE_TEXT.includes(kind)) return { correct: false, typo: false, accent: false, best: accepted[0] };
    for (const a of accepted) if (bare(normalise(a)) === bare(g)) return { correct: true, typo: true, accent: true, best: a };
    if (g.length >= 5)
      for (const a of accepted) { const n = normalise(a); if (n.length >= 5 && similarity(g, n) >= 0.9) return { correct: true, typo: true, accent: false, best: a }; }
    return { correct: false, typo: false, accent: false, best: accepted[0] };
  }
  const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
  const dayDiff = (a, b) => Math.round((a - b) / DAY);
  function lessonXp(base, correct, total, streak) {
    if (!total) return 0;
    let xp = Math.round(base * correct / total) + correct * CFG.xpPerCorrect;
    if (correct === total) xp += CFG.perfectBonus;
    return Math.round(xp * (1 + Math.min(Math.floor(streak / 7), 5) * 0.1));
  }
  function advanceStreak(s) {
    const t = today();
    if (s.last === t) return false;
    const gap = s.last == null ? null : dayDiff(t, s.last);
    if (gap === 2 && s.freezes > 0) { s.freezes--; s.streak++; }
    else if (gap === 1) s.streak++;
    else s.streak = 1;
    s.longest = Math.max(s.longest, s.streak); s.last = t; return true;
  }
  function effectiveStreak(s) {
    if (s.last == null) return 0;
    const gap = dayDiff(today(), s.last);
    return gap <= 1 || (gap === 2 && s.freezes > 0) ? s.streak : 0;
  }
  function refill(s) {
    const now = Date.now();
    if (s.hearts >= CFG.heartsMax) { s.heartsAt = now; return; }
    const gained = Math.floor((now - s.heartsAt) / (CFG.refillMin * 60000));
    if (gained > 0) { s.hearts = Math.min(CFG.heartsMax, s.hearts + gained); s.heartsAt += gained * CFG.refillMin * 60000; }
  }
  function sm2(c, q) {
    if (q < 3) { c.reps = 0; c.interval = 1; c.lapses++; }
    else { c.interval = c.reps === 0 ? 1 : c.reps === 1 ? 6 : Math.max(1, Math.round(c.interval * c.ease)); c.reps++; }
    c.ease = Math.max(1.3, c.ease + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)));
    c.due = Date.now() + c.interval * DAY;
  }
  function weekStart() { const d = new Date(); const day = (d.getDay() + 6) % 7; return new Date(d.getFullYear(), d.getMonth(), d.getDate() - day).getTime(); }
  function weekId() { const d = new Date(weekStart() + 3 * DAY); const y = d.getFullYear(); const jan4 = new Date(y, 0, 4); return `${y}-W${String(1 + Math.round((d - jan4) / (7 * DAY))).padStart(2, "0")}`; }
  const RIVALS = {
    es: [["Valentina", 0.55, 40], ["Mateo", 0.48, 25], ["Camila", 0.42, 60], ["Santiago", 0.36, 10], ["Lucía", 0.3, 35], ["Diego", 0.26, 15], ["Isabella", 0.2, 5], ["Joaquín", 0.15, 20], ["Renata", 0.1, 0]],
    en: [["Emma", 0.52, 45], ["Liam", 0.47, 20], ["Olivia", 0.4, 55], ["Noah", 0.35, 12], ["Ava", 0.29, 30], ["Ethan", 0.25, 18], ["Mia", 0.19, 6], ["Lucas", 0.14, 22], ["Harper", 0.1, 0]],
  };
  const rivalXp = (rate, base) => Math.round(base + rate * ((Date.now() - weekStart()) / 3600000) * 2.2);

  // ---- responses ----
  const ok = (data, status = 200) => ({ status, data });
  const fail = (status, code, message) => ({ status, data: { error: { code, message, request_id: Math.random().toString(16).slice(2) } } });
  const pub = (u) => ({ id: u.id, email: u.email, display_name: u.display_name, native_lang: u.native_lang, target_lang: u.target_lang, timezone: u.timezone, daily_goal_xp: u.daily_goal_xp, role: "learner", plan: u.plan, created_at: u.created_at });
  const tokens = () => ({ access_token: "demo." + Math.random().toString(36).slice(2), refresh_token: "demo-refresh-" + Math.random().toString(36).slice(2), token_type: "bearer", expires_in: 900 });
  const premium = () => db.user.plan === "premium";
  function todayXp() { const t = today(); return db.xp.filter((e) => e.at >= t).reduce((a, e) => a + e.amount, 0); }
  function award(amount, ref, course) {
    if (amount <= 0 || db.xp.some((e) => e.ref === ref)) return false;
    db.xp.push({ amount, ref, at: Date.now() });
    db.stats.total += amount;
    if (db.week !== weekId()) { db.week = weekId(); db.weekXp = {}; }
    if (course) db.weekXp[course] = (db.weekXp[course] || 0) + amount;
    return true;
  }
  const premiumMsg = () => (db.user.native_lang === "en" ? "This lesson is part of OmniVox Premium" : "Esta lección es parte de OmniVox Premium");

  const routes = [
    ["POST", /^\/auth\/(register|login)$/, (m, b) => {
      const en = String(b.native_lang || "es").startsWith("en");
      if (m[1] === "register") {
        if (!b.display_name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(b.email || "")) return fail(422, "validation_error", en ? "Check your name and email" : "Revisa tu nombre y correo");
        if (!b.password || b.password.length < 10 || b.password.toLowerCase() === b.password || !/\d/.test(b.password)) return fail(422, "validation_error", en ? "Password needs 10+ characters, a capital letter and a number" : "La contraseña necesita 10+ caracteres, una mayúscula y un número");
        db = { user: { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), email: b.email.toLowerCase(), display_name: b.display_name.slice(0, 60), native_lang: en ? "en" : "es", target_lang: b.target_lang || (en ? "es" : "en"), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, daily_goal_xp: 20, plan: "free", created_at: new Date().toISOString() },
          stats: { total: 0, streak: 0, longest: 0, last: null, freezes: 0, hearts: CFG.heartsMax, heartsAt: Date.now(), lessons: 0 },
          attempts: {}, completed: [], xp: [], cards: {}, tutor: [], week: weekId(), weekXp: {} };
        save(); return ok(tokens(), 201);
      }
      if (!db.user || db.user.email !== String(b.email || "").toLowerCase()) return fail(401, "bad_credentials", "Email or password is incorrect");
      return ok(tokens());
    }],
    ["GET", /^\/me$/, () => ok(pub(db.user))],
    ["PATCH", /^\/me$/, (m, b) => { ["display_name", "native_lang", "target_lang", "daily_goal_xp"].forEach((k) => { if (b[k] != null) db.user[k] = b[k]; }); save(); return ok(pub(db.user)); }],
    ["GET", /^\/me\/stats$/, () => { const s = db.stats; refill(s); save(); return ok({ total_xp: s.total, today_xp: todayXp(), daily_goal_xp: db.user.daily_goal_xp, current_streak: effectiveStreak(s), longest_streak: s.longest, streak_freezes: s.freezes, hearts: premium() ? null : s.hearts, lessons_completed: s.lessons, last_activity_date: s.last ? new Date(s.last).toISOString().slice(0, 10) : null }); }],
    ["GET", /^\/courses$/, () => ok(Object.values(courses).map((c) => c.meta))],
    ["GET", /^\/courses\/([\w-]+)\/path$/, (m) => {
      const c = courses[m[1]]; if (!c) return fail(404, "not_found", "Course not found");
      let next = true; const done = new Set(db.completed);
      const units = c.skeleton.map((u) => Object.assign({}, u, { lessons: u.lessons.map((l) => {
        let state;
        if (done.has(l.id)) state = "completed";
        else if (l.is_premium && !premium()) state = "premium";
        else if (next) { state = "available"; next = false; } else state = "locked";
        return Object.assign({}, l, { state });
      }) }));
      return ok({ course: c.meta, units });
    }],
    ["GET", /^\/lessons\/([\w-]+)$/, (m) => {
      const l = lessons[m[1]]; if (!l) return fail(404, "not_found", "Lesson not found");
      if (l.is_premium && !premium()) return fail(403, "premium_required", premiumMsg());
      return ok({ id: l.id, title: l.title, xp_reward: l.xp_reward, is_premium: l.is_premium, course_slug: l.course,
        exercises: l.exercises.map((id) => { const e = exercises[id]; return { id, position: e.position, kind: e.kind, prompt: e.prompt, payload: e.payload }; }) });
    }],
    ["POST", /^\/lessons\/([\w-]+)\/attempts$/, (m) => {
      const l = lessons[m[1]]; if (!l) return fail(404, "not_found", "Lesson not found");
      if (l.is_premium && !premium()) return fail(403, "premium_required", premiumMsg());
      refill(db.stats);
      if (!premium() && db.stats.hearts <= 0) return fail(403, "out_of_hearts", "Out of hearts");
      const id = "a" + Date.now().toString(36);
      db.attempts[id] = { lesson: l.id, answers: {}, done: null }; save();
      return ok({ attempt_id: id, lesson_id: l.id, hearts: premium() ? null : db.stats.hearts }, 201);
    }],
    ["POST", /^\/attempts\/([\w-]+)\/answers$/, (m, b) => {
      const a = db.attempts[m[1]]; if (!a) return fail(404, "not_found", "Attempt not found");
      if (a.done) return fail(409, "attempt_closed", "This attempt is already finished");
      const e = exercises[b.exercise_id]; if (!e || e.lesson_id !== a.lesson) return fail(404, "not_found", "Exercise not found");
      if (a.answers[e.id] != null) return fail(409, "already_answered", "Already answered");
      const r = grade(e.kind, b.answer, e.answers); a.answers[e.id] = r.correct;
      refill(db.stats);
      if (!r.correct && !premium()) db.stats.hearts = Math.max(0, db.stats.hearts - 1);
      if (r.correct && e.vocab) { const v = vid(e.ci, e.vocab); if (!db.cards[v]) db.cards[v] = { ease: 2.5, interval: 0, reps: 0, lapses: 0, due: Date.now() }; }
      save();
      return ok({ correct: r.correct, typo: r.typo, accent_missed: r.accent, correct_answer: r.best, explanation: e.explanation, hearts: premium() ? null : db.stats.hearts });
    }],
    ["POST", /^\/attempts\/([\w-]+)\/complete$/, (m) => {
      const a = db.attempts[m[1]]; if (!a) return fail(404, "not_found", "Attempt not found");
      let extended = false; const s = db.stats;
      if (!a.done) {
        const l = lessons[a.lesson]; const total = l.exercises.length;
        if (Object.keys(a.answers).length < total) return fail(409, "lesson_incomplete", "Answer every exercise first");
        const correct = Object.values(a.answers).filter(Boolean).length;
        extended = advanceStreak(s);
        const xp = lessonXp(l.xp_reward, correct, total, s.streak);
        a.done = { correct, total, xp: award(xp, "lesson:" + m[1], l.course) ? xp : 0 };
        s.lessons++; if (!db.completed.includes(l.id)) db.completed.push(l.id); save();
      }
      return ok({ attempt_id: m[1], correct: a.done.correct, total: a.done.total, xp_earned: a.done.xp, total_xp: s.total, streak: s.streak, streak_extended: extended, daily_goal_met: todayXp() >= db.user.daily_goal_xp });
    }],
    ["GET", /^\/review\/due$/, () => {
      const now = Date.now();
      return ok(Object.entries(db.cards).filter(([, c]) => c.due <= now).sort((a, b) => a[1].due - b[1].due).slice(0, 20)
        .map(([id, c]) => ({ vocab_id: id, term: vocab[id].term, translation: vocab[id].translation, example: vocab[id].example, audio_url: null, due_at: new Date(c.due).toISOString(), course: vocab[id].course })));
    }],
    ["POST", /^\/review\/([\w-]+)$/, (m, b) => {
      const c = db.cards[m[1]]; if (!c) return fail(404, "not_found", "Card not in your review deck");
      if (c.due > Date.now()) return ok({ due_at: new Date(c.due).toISOString(), interval_days: c.interval, xp_earned: 0 });
      sm2(c, b.quality); advanceStreak(db.stats);
      const earned = award(1, `review:${m[1]}:${c.reps}:${c.lapses}:${today()}`, vocab[m[1]].course) ? 1 : 0; save();
      return ok({ due_at: new Date(c.due).toISOString(), interval_days: c.interval, xp_earned: earned });
    }],
    ["GET", /^\/leaderboard\/weekly/, (m, b, query) => {
      const slug = query.get("course") || Object.keys(courses)[0];
      const c = courses[slug] || Object.values(courses)[0];
      if (db.week !== weekId()) { db.week = weekId(); db.weekXp = {}; save(); }
      const rows = RIVALS[c.meta.from_lang === "en" ? "en" : "es"].map(([n, r, base], i) => ({ user_id: "bot" + i, display_name: n, xp: rivalXp(r, base) }));
      const mine = db.weekXp[c.meta.slug] || 0;
      rows.push({ user_id: db.user.id, display_name: db.user.display_name, xp: mine });
      rows.sort((x, y) => y.xp - x.xp);
      const entries = rows.map((r, i) => Object.assign({ rank: i + 1 }, r));
      const me = entries.find((e) => e.user_id === db.user.id);
      return ok({ week: weekId(), scope: "course:" + c.meta.slug, entries, me: { rank: me.rank, xp: me.xp } });
    }],
    ["POST", /^\/tutor\/ask$/, (m, b) => {
      const hourAgo = Date.now() - 3600000;
      const limit = CFG.tutorPerHour * (premium() ? 5 : 1);
      const used = db.tutor.filter((t) => t > hourAgo).length;
      const ex = b.exercise_id && exercises[b.exercise_id];
      const lang = ex ? COURSES[ex.ci].from_lang : b.course && courses[b.course] ? courses[b.course].meta.from_lang : db.user.native_lang;
      if (used >= limit) return fail(429, "rate_limited", lang === "en" ? "You've reached this hour's question limit" : "Llegaste al límite de preguntas por esta hora");
      db.tutor.push(Date.now()); save();
      let answer = localTutor(b.question, lang);
      if (ex) answer = (lang === "en" ? `Here the answer is *${ex.answers[0]}*. ${ex.explanation}\n\n` : `En este ejercicio la respuesta es *${ex.answers[0]}*. ${ex.explanation}\n\n`) + answer;
      return ok({ answer, provider: "local", remaining_this_hour: limit - used - 1 });
    }],
    ["POST", /^\/billing\/checkout$/, () => { db.user.plan = "premium"; db.stats.freezes = Math.max(db.stats.freezes, 2); save(); return ok({ url: "#premium-success" }); }],
  ];

  const TIPS = {
    es: [
      [["do", "does"], "Usa *does* con he/she/it y *do* con I/you/we/they.\n• *She does her homework.*\n• *They do yoga.*\nEn preguntas: *Does he work here?* — el verbo va sin -s."],
      [["in", "on", "at"], "*at* para horas exactas (*at 5 pm*), *on* para días y fechas (*on Monday*), *in* para meses, años y partes del día (*in May*, *in the morning*)."],
      [["pasado", "past", "went", "ed"], "Pasado simple: verbos regulares + *-ed* (*work → worked*). Los irregulares se memorizan: *go → went*, *see → saw*, *eat → ate*."],
      [["am", "is", "are", "to be", "ser", "estar"], "*To be* = ser y estar a la vez.\n• *I am*\n• *you / we / they are*\n• *he / she / it is*\nEj.: *I am tired* (estoy cansado), *She is a teacher* (es maestra)."],
      [["an", "articulo"], "*an* antes de sonido vocal (*an apple*, *an hour*); *a* antes de sonido consonante (*a book*, *a university*)."],
      [["edad", "years", "old", "age"], "La edad se dice con *to be*, no con *have*: *I am 25 years old* (no ~~I have 25 years~~)."],
    ],
    en: [
      [["ser", "estar"], "*Ser* = what something IS: identity, origin, job, time.\n• *Soy de Texas.* (I'm from Texas)\n• *Es doctora.* (She's a doctor)\n*Estar* = how or where it is right now: feelings, location.\n• *Estoy cansado.* (I'm tired)\n• *Está en casa.* (He's at home)"],
      [["por", "para"], "*Para* points to a goal or destination: *Es para ti.* (It's for you)\n*Por* is the route, cause or exchange: *Gracias por todo.* (Thanks for everything)"],
      [["tu", "usted", "formal", "polite"], "*Tú* is informal: friends, family, kids.\n*Usted* is polite: strangers, elders, work. It takes the he/she verb form:\n• *¿Cómo estás?* (tú)\n• *¿Cómo está usted?* (usted)"],
      [["gender", "masculine", "feminine", "el", "la"], "Every noun is masculine or feminine. Most *-o* words are masculine (*el libro*), most *-a* words feminine (*la casa*). Tip: learn each noun with its article."],
      [["accent", "accents", "tilde"], "Accents mark the stressed syllable (*está*) or tell words apart (*tú* = you, *tu* = your). OmniVox accepts answers without accents but shows you where they go."],
      [["gustar", "like"], "*Gustar* works backwards: *Me gusta el café* = coffee is pleasing to me.\nFor plural things: *Me gustan los tacos.*"],
      [["past", "preterite", "pasado"], "Preterite of *-ar* verbs: *hablé, hablaste, habló, hablamos, hablaron*.\nCommon irregulars: *ir → fui*, *ver → vi*, *hacer → hice*."],
      [["age", "old", "years"], "Spanish uses *tener* (to have) for age: *Tengo 30 años* = I am 30 years old."],
    ],
  };
  function localTutor(q, lang) {
    const n = " " + bare(normalise(q)) + " ";
    const L = lang === "en" ? "en" : "es";
    for (const [keys, tip] of TIPS[L]) if (keys.some((k) => n.includes(" " + bare(normalise(k)) + " "))) return tip;
    return L === "en"
      ? "Good question! Write it with an example sentence in Spanish and I'll walk you through it step by step.\nMeanwhile, practice your words in *Review*."
      : "¡Buena pregunta! Escríbela con una frase de ejemplo en inglés y te la explico paso a paso.\nMientras tanto, repasa tus palabras en *Repaso*.";
  }

  async function handle(method, fullPath, body) {
    const [rawPath, qs] = fullPath.replace(/^\/api\/v1/, "").split("?");
    await new Promise((r) => setTimeout(r, 35 + Math.random() * 70)); // realistic latency
    if (!rawPath.startsWith("/auth/") && !db.user) return fail(401, "unauthorized", "Sign in required");
    for (const [m, re, fn] of routes) {
      const match = method === m && rawPath.match(re);
      if (match) return fn(match, body || {}, new URLSearchParams(qs || ""));
    }
    return fail(404, "not_found", "Not found");
  }

  window.OmniEngine = { handle, reset() { db = { user: null }; save(); }, get hasUser() { return !!db.user; } };
})();
