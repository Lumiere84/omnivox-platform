/* OmniVox web app: auth, learning path, lesson player, review, league, tutor, premium.
   Plain JS + small render helpers; each view is a function that renders into #app. */
(function () {
  const t = (k, v) => I18N.t(k, v);
  const $app = document.getElementById("app");
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  };
  const state = { me: null, stats: null, path: null, board: null, due: [], lesson: null, log: [], courses: [], course: store.get("ov.course") };
  const courseMeta = (slug) => state.courses.find((c) => c.slug === (slug || state.course)) || {};

  // ---------- tiny DOM helpers ----------
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const rich = (s) => esc(s).replace(/\*([^*]+)\*/g, "<em>$1</em>").replace(/~~([^~]+)~~/g, "<s>$1</s>");
  const h = (html) => { const tpl = document.createElement("template"); tpl.innerHTML = html.trim(); return tpl.content; };
  const qs = (sel, root = document) => root.querySelector(sel);
  const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const I = {
    logo: '<svg viewBox="0 0 40 40" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="40" height="40" rx="12" fill="url(#lg)"/><path d="M9 20h3M15 14v12M20 10v20M25 14v12M30 18v4" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    flame: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2s5 4.5 5 10a5 5 0 0 1-10 0c0-2 1-3.5 1-3.5S9 11 10.5 11C10.5 7 12 2 12 2Zm0 20a7 7 0 0 0 7-7c0-1.8-.6-3.4-1.4-4.7.1 3-2 5.2-4.1 5.7 1-1.6.5-3.5-1.5-4.5 0 2.5-3 3.2-3 6A3 3 0 0 0 12 21a7 7 0 0 1 0 1Z"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21s-7.5-4.6-9.5-9.2C1 8.3 3.3 4.5 7 4.5c2 0 3.4 1 5 3 1.6-2 3-3 5-3 3.7 0 6 3.8 4.5 7.3C19.5 16.4 12 21 12 21Z"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2 3 6.6 7 .7-5.3 4.7 1.6 7L12 17.4 5.7 21l1.6-7L2 9.3l7-.7L12 2Z"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12 5 5L20 7"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 10V7a5 5 0 0 1 10 0v3h1a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h1Zm2 0h6V7a3 3 0 0 0-6 0v3Z"/></svg>',
    crown: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 12H5L3 7Z"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    speaker: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4V9Zm12.5 3a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4Zm-2.5-8.8v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6Z"/></svg>',
    turtle: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M3 15c0-4 3.6-7 8-7s8 3 8 7H3Zm16-2c1.5 0 3-1 3-2.5S20.5 8 19 9.5V13ZM5 16h3v3H5v-3Zm9 0h3v3h-3v-3Z"/></svg>',
    chat: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4v-4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Zm4 6.5a1.5 1.5 0 1 0 0 .01Zm4 0a1.5 1.5 0 1 0 0 .01Zm4 0a1.5 1.5 0 1 0 0 .01Z"/></svg>',
    cards: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="6" width="14" height="14" rx="3"/><path d="M7 3h11a3 3 0 0 1 3 3v11"/></svg>',
  };

  // ---------- toast ----------
  let toastTimer;
  function toast(msg) {
    qsa(".toast").forEach((n) => n.remove());
    const el = h(`<div class="toast" role="status">${esc(msg)}</div>`).firstChild;
    document.body.appendChild(el);
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.remove(), 2600);
  }

  // ---------- speech (female US voice when available) ----------
  // Female voices preferred: US English for the English course, Latin American Spanish for the Spanish one.
  const VOICES = {
    en: { lang: "en-US", re: /^en(-|_)US/i, female: /female|samantha|zira|aria|jenny|ava|allison|google us english/i },
    es: { lang: "es-MX", re: /^es(-|_)(MX|US|419|CO|AR)/i, female: /female|paulina|sabina|dalia|monica|mónica|helena|laura|google español de estados unidos/i },
  };
  const voices = {};
  function pickVoices() {
    if (!("speechSynthesis" in window)) return;
    const all = speechSynthesis.getVoices();
    for (const [k, v] of Object.entries(VOICES)) {
      const vs = all.filter((x) => v.re.test(x.lang));
      const anyEs = k === "es" ? all.filter((x) => /^es/i.test(x.lang)) : [];
      voices[k] = vs.find((x) => v.female.test(x.name)) || vs[0] || anyEs[0] || null;
    }
  }
  if ("speechSynthesis" in window) { pickVoices(); speechSynthesis.onvoiceschanged = pickVoices; }
  function speak(text, rate = 0.95, lang) {
    if (!("speechSynthesis" in window)) { toast(text); return; }
    const L = (lang || courseMeta().to_lang || "en").startsWith("es") ? "es" : "en";
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); u.lang = VOICES[L].lang; u.rate = rate;
    if (voices[L]) u.voice = voices[L];
    speechSynthesis.speak(u);
  }

  // ---------- data ----------
  async function ensureCourse() {
    if (!state.courses.length) state.courses = await API.get("/courses");
    if (!state.courses.some((c) => c.slug === state.course)) {
      const me = state.me || (state.me = await API.get("/me"));
      const pick = state.courses.find((c) => c.from_lang === me.native_lang && c.to_lang === me.target_lang)
        || state.courses.find((c) => c.from_lang === me.native_lang) || state.courses[0];
      state.course = pick.slug; store.set("ov.course", state.course);
    }
  }

  async function refresh(parts = ["me", "stats", "path", "board", "due"]) {
    await ensureCourse();
    const COURSE_SLUG = state.course;
    const jobs = {
      me: () => API.get("/me").then((d) => (state.me = d)),
      stats: () => API.get("/me/stats").then((d) => (state.stats = d)),
      path: () => API.get(`/courses/${COURSE_SLUG}/path`).then((d) => (state.path = d)),
      board: () => API.get(`/leaderboard/weekly?course=${COURSE_SLUG}`).then((d) => (state.board = d)),
      due: () => API.get("/review/due").then((d) => (state.due = d)),
    };
    await Promise.all(parts.map((p) => jobs[p]()));
  }

  // ---------- shell ----------
  function topbar(active) {
    const s = state.stats || {}; const premium = state.me && state.me.plan === "premium";
    return `<header class="topbar"><div class="wrap">
      <button class="brand" data-go="learn" aria-label="OmniVox">${I.logo}<span>OmniVox</span></button>
      <nav class="nav" aria-label="Main">
        <button data-go="learn" ${active === "learn" ? 'aria-current="page"' : ""}>${t("learn")}</button>
        <button data-go="review" ${active === "review" ? 'aria-current="page"' : ""}>${t("review")}${state.due.length ? `<span class="badge">${state.due.length}</span>` : ""}</button>
        <button data-go="league" ${active === "league" ? 'aria-current="page"' : ""}>${t("league")}</button>
      </nav>
      <div class="chips">
        <span class="chip flame ${s.current_streak ? "" : "dim"}" title="${t("streak")}">${I.flame}${s.current_streak || 0}</span>
        <span class="chip xp" title="XP">${I.bolt}${s.total_xp || 0}</span>
        ${premium ? `<span class="chip pro" title="Premium">${I.crown}PRO</span>` : `<button class="chip heart" data-premium title="Hearts">${I.heart}${s.hearts == null ? "∞" : s.hearts}</button>`}
        ${state.courses.length > 1 ? `<button class="lang-toggle course-toggle" data-switch title="${t("switchCourse")}">${esc((courseMeta().from_lang || "").toUpperCase())} → ${esc((courseMeta().to_lang || "").toUpperCase())}</button>` : ""}
        <button class="lang-toggle" data-lang aria-label="Language">${I18N.lang === "es" ? "EN" : "ES"}</button>
      </div>
    </div></header>`;
  }

  function devlog() {
    return `<details class="devlog" id="devlog"><summary><span class="dot"></span>${t("apiLog")} · <span class="mono" id="logcount">${state.log.length}</span> · ${window.OMNIVOX_DEMO ? "demo engine" : t("live")}</summary><ol id="logrows">${state.log.slice(-60).map(logRow).join("")}</ol></details>`;
  }
  function logRow(e) {
    return `<li><span class="m-${e.method}">${e.method}</span><span class="${e.status < 400 ? "s-ok" : "s-err"}">${e.status}</span><span>${esc(e.path)}</span><span class="muted">${e.ms}ms</span></li>`;
  }
  API.onCall((e) => {
    state.log.push(e);
    const rows = qs("#logrows"); const count = qs("#logcount");
    if (rows) { rows.insertAdjacentHTML("beforeend", logRow(e)); rows.scrollTop = rows.scrollHeight; }
    if (count) count.textContent = state.log.length;
  });

  function mount(html, active) {
    const open = qs("#devlog") && qs("#devlog").open;
    $app.innerHTML = (active ? topbar(active) : "") + html + devlog() + (active ? `<button class="fab" data-tutor aria-label="${t("tutor")}">${I.chat}</button>` : "");
    if (open) qs("#devlog").open = true;
    const rows = qs("#logrows"); if (rows) rows.scrollTop = rows.scrollHeight;
  }

  document.addEventListener("click", (ev) => {
    const go = ev.target.closest("[data-go]");
    if (go) { location.hash = "#" + go.dataset.go; return; }
    if (ev.target.closest("[data-lang]")) { I18N.set(I18N.lang === "es" ? "en" : "es"); route(); return; }
    if (ev.target.closest("[data-premium]")) { premiumModal(); return; }
    if (ev.target.closest("[data-tutor]")) { openTutor(); return; }
    if (ev.target.closest("[data-switch]")) { switchCourse(); return; }
  });

  async function switchCourse() {
    const i = state.courses.findIndex((c) => c.slug === state.course);
    const next = state.courses[(i + 1) % state.courses.length];
    state.course = next.slug; store.set("ov.course", next.slug);
    I18N.set(next.from_lang === "en" ? "en" : "es");
    if (tutorEl) { tutorEl.remove(); tutorEl = null; }
    toast(next.title);
    location.hash = "#learn"; route();
  }

  // ---------- auth ----------
  function viewAuth(mode = "signup") {
    const demo = !!window.OMNIVOX_DEMO;
    const learn = state.signupLearn || (I18N.lang === "en" ? "es" : "en");
    const choice = (code) => `<button type="button" class="pick ${learn === code ? "on" : ""}" data-learn="${code}" aria-pressed="${learn === code}">
        <span class="flag">${code.toUpperCase()}</span><span><b>${t(code === "en" ? "optEn" : "optEs")}</b><small>${t(code === "en" ? "optEnSub" : "optEsSub")}</small></span></button>`;
    mount(`<main class="wrap auth">
      <section class="auth-hero">
        <div class="brand" style="margin-bottom:22px">${I.logo}<span>OmniVox</span></div>
        <h1>${t("tagline")}</h1>
        <div class="wave" aria-hidden="true">${Array.from({ length: 26 }, (_, i) => `<i style="animation-delay:${(i % 9) * -0.13}s"></i>`).join("")}</div>
        <p>${t("pitch")}</p>
      </section>
      <section class="card">
        <div class="tabs" role="tablist">
          <button role="tab" aria-selected="${mode === "signup"}" data-mode="signup">${t("signup")}</button>
          <button role="tab" aria-selected="${mode === "login"}" data-mode="login">${t("login")}</button>
        </div>
        <form class="form" id="authform" style="margin-top:18px" novalidate>
          ${mode === "signup" ? `<div class="field"><span class="field-label">${t("chooseTitle")}</span><div class="picks">${choice("es")}${choice("en")}</div></div>` : ""}
          ${mode === "signup" ? `<div class="field"><label for="f-name">${t("name")}</label><input class="input" id="f-name" autocomplete="nickname" required value="${demo ? (learn === "es" ? "Mike" : "Ana") : ""}"></div>` : ""}
          <div class="field"><label for="f-email">${t("email")}</label><input class="input" id="f-email" type="email" autocomplete="email" required value="${demo ? (learn === "es" ? "mike@omnivox.demo" : "ana@omnivox.demo") : ""}"></div>
          <div class="field"><label for="f-pass">${t("password")}</label><input class="input" id="f-pass" type="password" autocomplete="${mode === "signup" ? "new-password" : "current-password"}" required value="${demo ? "Aprender2026" : ""}"><span class="hint">${mode === "signup" ? t("pwHint") : ""}</span></div>
          <div class="error" id="autherr" role="alert"></div>
          <button class="btn btn-primary btn-block" type="submit">${mode === "signup" ? t("start") : t("welcomeBack")}</button>
          ${demo ? `<p class="hint" style="margin:0;text-align:center">${t("demoNote")}</p>` : ""}
        </form>
      </section></main>`);
    qsa("[data-mode]").forEach((b) => b.addEventListener("click", () => viewAuth(b.dataset.mode)));
    qsa("[data-learn]").forEach((b) => b.addEventListener("click", () => {
      state.signupLearn = b.dataset.learn;
      I18N.set(b.dataset.learn === "es" ? "en" : "es");  // interface in the learner's own language
      viewAuth("signup");
    }));
    qs("#authform").addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const body = { email: qs("#f-email").value.trim(), password: qs("#f-pass").value };
      try {
        if (mode === "signup") {
          body.display_name = qs("#f-name").value.trim();
          body.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || "America/Mexico_City";
          body.native_lang = learn === "es" ? "en" : "es";
          body.target_lang = learn;
          await API.post("/auth/register", body);
          state.course = null; state.courses = []; state.me = null;
        } else await API.post("/auth/login", body);
        location.hash = "#learn"; route();
      } catch (e) { qs("#autherr").textContent = e.message; }
    });
  }

  // ---------- home ----------
  const NODE_X = [0, 70, 100, 60, -10, -70, -90, -40];
  const nodeIcon = { completed: I.check, available: I.star, locked: I.lock, premium: I.crown };

  function sidebar() {
    const s = state.stats; const goal = s.daily_goal_xp; const pct = Math.min(1, s.today_xp / goal); const C = 2 * Math.PI * 38;
    const b = state.board;
    const premium = state.me.plan === "premium";
    const colors = ["#22d3ee", "#a78bfa", "#fbbf24", "#34d399", "#fb7185", "#f0abfc", "#60a5fa", "#fdba74", "#5eead4", "#c4b5fd"];
    const top = b.entries.slice(0, 7);
    if (b.me && !top.some((e) => e.user_id === state.me.id)) top.push(b.entries.find((e) => e.user_id === state.me.id));
    return `<aside class="side">
      <section class="card goal">
        <svg class="ring" viewBox="0 0 88 88" role="img" aria-label="${s.today_xp} / ${goal} XP"><circle class="track" cx="44" cy="44" r="38"/><circle class="bar" cx="44" cy="44" r="38" transform="rotate(-90 44 44)" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - pct)}"/><text x="44" y="50" text-anchor="middle" fill="currentColor" font-family="JetBrains Mono, monospace" font-weight="700" font-size="17">${s.today_xp}</text></svg>
        <div><div class="eyebrow">${t("dailyGoal")}</div><h3 style="margin:4px 0">${pct >= 1 ? t("goalMet") : `${s.today_xp} ${t("ofGoal", { n: goal })}`}</h3>
        <div class="muted" style="font-size:14px">${I18N.lang === "es" ? "Racha récord" : "Best streak"}: <span class="mono">${s.longest_streak}</span></div></div>
      </section>
      <section class="card league">
        <div class="eyebrow">${b.week}</div><h3>${t("weeklyLeague")}</h3>
        <ol>${top.map((e, i) => `<li class="${e.user_id === state.me.id ? "me" : ""}"><span class="rank">${e.rank}</span><span class="avatar" style="background:${colors[i % colors.length]}">${esc(e.display_name[0])}</span><span class="name">${esc(e.display_name)}</span><span class="pts">${e.xp}</span></li>`).join("")}</ol>
        <p class="hint" style="margin:8px 0 0">${t("resetsIn")}</p>
      </section>
      <section class="card">
        <div class="eyebrow">${t("review")}</div>
        <h3 style="margin:6px 0">${state.due.length} ${t("due")}</h3>
        <button class="btn btn-cyan btn-block" data-go="review" ${state.due.length ? "" : "disabled"}>${t("review")}</button>
      </section>
      <button class="btn btn-ghost" id="signout">${t("signOut")}</button>
      ${premium ? "" : `<section class="card promo"><div class="eyebrow" style="color:var(--violet-ink)">${I.crown.replace("<svg", '<svg width="14" height="14"')} PRO</div><h3 style="margin-top:6px">${t("premiumTitle")}</h3><p>${t("premiumPitch")}</p><button class="btn btn-primary btn-block" data-premium>${t("goPremium")}</button></section>`}
    </aside>`;
  }

  function viewHome() {
    const units = state.path.units.map((u, ui) => `<section class="unit">
      <div class="unit-head u${(ui % 3) + 1}"><div><div class="eyebrow" style="color:rgba(255,255,255,.75)">${I18N.lang === "es" ? "Unidad" : "Unit"} ${u.position}</div><h2>${esc(u.title)}</h2><p>${esc(u.description)}</p></div></div>
      <div class="trail">${u.lessons.map((l, li) => `<button class="node ${l.state}" data-lesson="${l.id}" data-state="${l.state}" style="--x:${NODE_X[(li + ui * 3) % NODE_X.length]}px" aria-label="${esc(l.title)}">
          ${l.state === "available" ? `<span class="start-tip">${t("start_")}</span>` : ""}
          <span class="disc">${nodeIcon[l.state]}</span><span class="label">${esc(l.title)}</span></button>`).join("")}</div>
    </section>`).join("");
    mount(`<main class="wrap home"><div>${units}</div>${sidebar()}</main>`, "learn");
    bindSignOut();
    qsa("[data-lesson]").forEach((b) => b.addEventListener("click", () => {
      const st = b.dataset.state;
      if (st === "locked") return toast(t("locked"));
      if (st === "premium") return premiumModal();
      startLesson(b.dataset.lesson);
    }));
  }

  function viewLeague() {
    mount(`<main class="wrap" style="padding-block:28px 64px;max-width:640px">${sidebar()}</main>`, "league");
    bindSignOut();
  }

  function bindSignOut() {
    const b = qs("#signout");
    if (b) b.onclick = () => { if (window.OMNIVOX_DEMO) window.OmniEngine.reset(); API.signOut(); Object.assign(state, { me: null, course: null, courses: [] }); location.hash = ""; viewAuth(); };
  }

  // ---------- lesson player ----------
  async function startLesson(id) {
    try {
      const [lesson, attempt] = await Promise.all([API.get(`/lessons/${id}`), API.post(`/lessons/${id}/attempts`)]);
      state.lesson = { data: lesson, attempt: attempt.attempt_id, i: 0, hearts: attempt.hearts, correct: 0 };
      renderExercise();
    } catch (e) {
      if (e.code === "out_of_hearts") return outOfHearts();
      if (e.code === "premium_required") return premiumModal();
      toast(e.message);
    }
  }

  function lessonFrame(inner, foot) {
    const L = state.lesson; const n = L.data.exercises.length;
    return `<main class="lesson">
      <div class="lesson-top">
        <button class="icon-btn" id="quit" aria-label="${t("exitLesson")}">${I.close}</button>
        <div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${L.i}"><i style="width:${(L.i / n) * 100}%"></i></div>
        <span class="chip heart">${I.heart}${L.hearts == null ? "∞" : L.hearts}</span>
      </div>
      <section class="ex" id="ex">${inner}</section>
      <div id="foot">${foot}</div>
    </main>`;
  }

  function renderExercise() {
    const L = state.lesson; const ex = L.data.exercises[L.i]; const p = ex.payload || {};
    let body = "";
    if (ex.kind === "multiple_choice") {
      body = `<div class="choices" role="group">${p.choices.map((c, i) => `<button class="choice" data-choice="${esc(c)}" aria-pressed="false"><span class="key">${i + 1}</span>${esc(c)}</button>`).join("")}</div>`;
    } else if (ex.kind === "fill_blank") {
      body = `<div class="sentence">${esc(p.sentence).replace("___", '<span style="color:var(--cyan)">_____</span>')}</div>
        <input class="input" id="answer" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${t("typeHere")}">${p.hint ? `<span class="hint">${esc(p.hint)}</span>` : ""}`;
    } else if (ex.kind === "translate") {
      body = `<textarea class="input" id="answer" autocomplete="off" spellcheck="false" placeholder="${t("typeHere")}"></textarea>${p.hint ? `<span class="hint">${esc(p.hint)}</span>` : ""}`;
    } else if (ex.kind === "listen_type") {
      body = `<div class="listen"><button class="speaker" id="say" aria-label="Play">${I.speaker}</button><button class="speaker slow" id="sayslow" aria-label="Slow">${I.turtle}</button></div>
        <textarea class="input" id="answer" autocomplete="off" spellcheck="false" placeholder="${t("typeHere")}"></textarea>`;
    } else if (ex.kind === "word_bank") {
      const words = shuffle(p.words.slice());
      body = `<span class="hint">${t("tapWords")}</span><div class="answer-zone" id="zone"></div><div class="bank" id="bank">${words.map((w, i) => `<button class="word" data-w="${esc(w)}" data-i="${i}">${esc(w)}</button>`).join("")}</div>`;
    }
    $app.innerHTML = lessonFrame(`<div class="eyebrow ex-kind">${t("kinds." + ex.kind)}</div><h2>${esc(ex.prompt)}</h2>${body}`,
      `<div class="lesson-foot"><button class="btn btn-primary" id="checkbtn" disabled>${t("check")}</button></div>`) + devlog();
    qs("#quit").onclick = () => { state.lesson = null; location.hash = "#learn"; route(); };
    const check = qs("#checkbtn");
    let value = () => "";
    if (ex.kind === "multiple_choice") {
      let chosen = null;
      qsa("[data-choice]").forEach((b) => b.addEventListener("click", () => {
        qsa("[data-choice]").forEach((x) => x.setAttribute("aria-pressed", "false"));
        b.setAttribute("aria-pressed", "true"); chosen = b.dataset.choice; check.disabled = false;
        speak(chosen);
      }));
      value = () => chosen;
      L.keys = (k) => { const b = qsa("[data-choice]")[Number(k) - 1]; if (b) b.click(); };
    } else if (ex.kind === "word_bank") {
      const picked = [];
      const zone = qs("#zone");
      qsa("#bank .word").forEach((b) => b.addEventListener("click", () => {
        b.classList.add("used"); picked.push(b.dataset.w);
        const chip = h(`<button class="word">${esc(b.dataset.w)}</button>`).firstChild;
        chip.onclick = () => { picked.splice(picked.indexOf(b.dataset.w), 1); chip.remove(); b.classList.remove("used"); check.disabled = !picked.length; };
        zone.appendChild(chip); check.disabled = false;
      }));
      value = () => picked.join(" ");
    } else {
      const input = qs("#answer");
      input.addEventListener("input", () => { check.disabled = !input.value.trim(); });
      input.focus();
      value = () => input.value;
      if (ex.kind === "listen_type") {
        qs("#say").onclick = () => speak(p.tts_text);
        qs("#sayslow").onclick = () => speak(p.tts_text, 0.6);
        setTimeout(() => speak(p.tts_text), 300);
      }
    }
    check.onclick = () => submit(ex, value());
  }

  async function submit(ex, answer) {
    const L = state.lesson; const check = qs("#checkbtn"); check.disabled = true;
    let r;
    try { r = await API.post(`/attempts/${L.attempt}/answers`, { exercise_id: ex.id, answer }); }
    catch (e) { toast(e.message); check.disabled = false; return; }
    L.hearts = r.hearts; if (r.correct) L.correct++;
    qs(".lesson-top .chip").innerHTML = I.heart + (r.hearts == null ? "∞" : r.hearts);
    if (!r.correct) qs("#ex").classList.add("shake");
    qsa("#ex button, #ex input, #ex textarea").forEach((n) => (n.disabled = true));
    qs("#foot").innerHTML = `<div class="feedback ${r.correct ? "ok" : "no"}" role="status">
      <h3>${r.correct ? (r.accent_missed ? t("accentMissed") : r.typo ? t("almost") : t("correct")) : t("wrong")}</h3>
      ${!r.correct || r.typo ? `<div style="font-size:18px;font-weight:700">${esc(r.correct_answer)}</div>` : ""}
      <div class="muted">${esc(r.explanation)}</div>
      <div class="row"><button class="btn btn-ghost" data-ask="${esc(ex.id)}">${I.chat.replace("<svg", '<svg width="18" height="18"')} ${t("askTutor")}</button>
      <button class="btn ${r.correct ? "btn-good" : "btn-bad"}" id="next">${t("continue_")}</button></div></div>`;
    if (r.correct) speak(r.correct_answer || answer);
    qs("[data-ask]").onclick = () => openTutor(ex.id, courseMeta().from_lang === "en" ? `Why is the answer "${r.correct_answer}"?` : `¿Por qué la respuesta es «${r.correct_answer}»?`);
    const next = qs("#next"); next.focus();
    next.onclick = async () => {
      L.i++;
      if (L.i < L.data.exercises.length) {
        if (L.hearts === 0) return outOfHearts();
        renderExercise();
      } else finishLesson();
    };
  }

  async function finishLesson() {
    const L = state.lesson;
    const r = await API.post(`/attempts/${L.attempt}/complete`);
    await refresh(["stats", "path", "board", "due"]);
    const acc = Math.round((r.correct / r.total) * 100);
    $app.innerHTML = `<main class="done wrap"><div style="display:grid;justify-items:center">
      <div class="eyebrow" style="color:var(--amber)">${esc(L.data.title)}</div>
      <h1>${t("lessonDone")}</h1>
      ${r.streak_extended ? `<p style="font-size:19px;color:var(--flame);font-weight:700">${t("streakUp", { n: r.streak, d: I18N.lang === "es" ? (r.streak === 1 ? "día" : "días") : (r.streak === 1 ? "day" : "days") })}</p>` : ""}
      <div class="tiles">
        <div class="tile xp"><b>${t("xpEarned")}</b><span id="countxp">0</span></div>
        <div class="tile acc"><b>${t("accuracy")}</b><span>${acc}%</span></div>
        <div class="tile st"><b>${t("streak")}</b><span>${r.streak}</span></div>
      </div>
      <button class="btn btn-primary" id="home">${t("backHome")}</button></div></main><canvas id="confetti"></canvas>` + devlog();
    countUp(qs("#countxp"), r.xp_earned);
    if (acc >= 60) confetti();
    qs("#home").onclick = () => { location.hash = "#learn"; route(); };
    qs("#home").focus();
    state.lesson = null;
  }

  function outOfHearts() {
    $app.innerHTML = `<main class="done wrap"><div class="card" style="max-width:440px;text-align:center;display:grid;gap:12px;justify-items:center">
      <span style="color:var(--bad)">${I.heart.replace("<svg", '<svg width="72" height="72"')}</span>
      <h1 style="font-size:32px">${t("outOfHearts")}</h1><p class="muted" style="margin:0">${t("heartsRefill")}</p>
      <button class="btn btn-primary btn-block" data-premium>${t("goPremium")}</button>
      <button class="btn btn-ghost btn-block" data-go="learn">${t("backHome")}</button></div></main>` + devlog();
    state.lesson = null;
  }

  // ---------- review ----------
  function viewReview() {
    const card = state.due[0];
    if (!card) {
      mount(`<main class="wrap review"><div class="empty">${I.cards}<h1 style="margin:10px 0">${t("nothingDue")}</h1><p class="muted">${t("nothingDueSub")}</p><button class="btn btn-primary" data-go="learn">${t("learn")}</button></div></main>`, "review");
      return;
    }
    mount(`<main class="wrap review">
      <div style="text-align:center"><h1>${t("reviewTitle")}</h1><p class="muted" style="margin:6px 0 0">${t("reviewSub")} · <span class="mono">${state.due.length}</span> ${t("due")}</p></div>
      <button class="flash" id="flash" aria-label="${t("tapToFlip")}"><div class="flash-inner">
        <div class="face front"><div class="term">${esc(card.term)}</div><div class="muted">${t("tapToFlip")}</div></div>
        <div class="face back"><div class="term">${esc(card.translation)}</div><div style="opacity:.9">${esc(card.example)}</div></div>
      </div></button>
      <div class="grades" id="grades" hidden>
        <button class="btn btn-bad" data-q="1">${t("again")}<small>1d</small></button>
        <button class="btn btn-ghost" data-q="3">${t("hard")}<small>1d+</small></button>
        <button class="btn btn-cyan" data-q="4">${t("good")}<small>6d</small></button>
        <button class="btn btn-good" data-q="5">${t("easy")}<small>6d+</small></button>
      </div></main>`, "review");
    const flash = qs("#flash");
    speak(card.term, 0.95, courseMeta(card.course).to_lang);
    flash.onclick = () => { flash.classList.toggle("flipped"); qs("#grades").hidden = false; };
    qsa("[data-q]").forEach((b) => b.addEventListener("click", async () => {
      const r = await API.post(`/review/${card.vocab_id}`, { quality: Number(b.dataset.q) });
      if (r.xp_earned) toast(t("xpToast", { n: r.xp_earned }));
      await refresh(["due", "stats", "board"]);
      viewReview();
    }));
  }

  // ---------- tutor ----------
  let tutorEl = null;
  function openTutor(exerciseId, preset) {
    if (!tutorEl) {
      tutorEl = h(`<aside class="drawer" aria-label="${t("tutor")}"><header>${I.logo.replace("<svg", '<svg width="30" height="30"')}<h3>${t("tutor")}</h3><button class="icon-btn" id="tclose" aria-label="Close">${I.close}</button></header>
        <div class="chat" id="chat"><div class="msg bot">${esc(t("tutorHi"))}</div></div>
        <div class="suggest">${(courseMeta().from_lang === "en" ? ["u1", "u2", "u3"] : ["t1", "t2", "t3"]).map((k) => `<button data-s="${esc(t(k))}">${esc(t(k))}</button>`).join("")}</div>
        <form class="chat-form" id="tform"><input class="input" id="tq" placeholder="${t("ask")}" maxlength="800" autocomplete="off"><button class="btn btn-primary" type="submit">${t("send")}</button></form>
        <div class="hint" id="tleft" style="padding:0 14px 12px"></div></aside>`).firstChild;
      document.body.appendChild(tutorEl);
      qs("#tclose").onclick = () => tutorEl.classList.remove("open");
      qsa("[data-s]", tutorEl).forEach((b) => b.addEventListener("click", () => ask(b.dataset.s)));
      qs("#tform").addEventListener("submit", (ev) => { ev.preventDefault(); const q = qs("#tq").value.trim(); if (q.length > 1) ask(q); });
    }
    tutorEl.dataset.exercise = exerciseId || "";
    requestAnimationFrame(() => tutorEl.classList.add("open"));
    if (preset) ask(preset);
    else setTimeout(() => qs("#tq").focus(), 250);
  }
  async function ask(q) {
    const chat = qs("#chat");
    chat.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(q)}</div><div class="msg bot" id="typing">…</div>`);
    qs("#tq").value = ""; chat.scrollTop = chat.scrollHeight;
    try {
      const body = { question: q, course: state.course }; if (tutorEl.dataset.exercise) body.exercise_id = tutorEl.dataset.exercise;
      const r = await API.post("/tutor/ask", body);
      qs("#typing").outerHTML = `<div class="msg bot">${rich(r.answer)}</div>`;
      qs("#tleft").textContent = t("left", { n: r.remaining_this_hour });
    } catch (e) { qs("#typing").outerHTML = `<div class="msg bot">${esc(e.message)}</div>`; }
    chat.scrollTop = chat.scrollHeight;
  }

  // ---------- premium ----------
  function premiumModal() {
    const el = h(`<div class="scrim" id="scrim"><div class="card modal" role="dialog" aria-modal="true" aria-labelledby="ptitle">
      <div class="eyebrow" style="color:var(--violet-ink)">PRO</div><h2 id="ptitle" style="font-size:30px;margin-top:4px">${t("premiumTitle")}</h2>
      <div><span class="price">$6.99</span><span class="muted">${t("perMonth")}</span></div>
      <ul class="plan-list">${["p1", "p2", "p3", "p4"].map((k) => `<li>${I.check}${t(k)}</li>`).join("")}</ul>
      <div style="display:grid;gap:10px"><button class="btn btn-primary" id="buy">${window.OMNIVOX_DEMO ? t("activate") : t("goPremium")}</button><button class="btn btn-ghost" id="nope">${t("notNow")}</button></div>
    </div></div>`).firstChild;
    document.body.appendChild(el);
    const close = () => el.remove();
    el.addEventListener("click", (e) => { if (e.target === el) close(); });
    qs("#nope").onclick = close;
    qs("#buy").onclick = async () => {
      try {
        const r = await API.post("/billing/checkout");
        if (window.OMNIVOX_DEMO) { close(); toast(t("premiumOn")); await refresh(); route(); confetti(); }
        else location.href = r.url;
      } catch (e) { toast(e.message); }
    };
    qs("#buy").focus();
  }

  // ---------- effects ----------
  function countUp(el, to) {
    const start = performance.now();
    const step = (now) => { const p = Math.min(1, (now - start) / 900); el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }
  function confetti() {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let c = qs("#confetti");
    if (!c) { c = document.createElement("canvas"); c.id = "confetti"; document.body.appendChild(c); }
    const ctx = c.getContext("2d"); c.width = innerWidth; c.height = innerHeight;
    const colors = ["#22d3ee", "#8b5cf6", "#fbbf24", "#34d399", "#fb7185", "#f0abfc"];
    const bits = Array.from({ length: 160 }, () => ({ x: Math.random() * c.width, y: -20 - Math.random() * c.height * 0.5, r: 4 + Math.random() * 6, vx: -2 + Math.random() * 4, vy: 2 + Math.random() * 4, a: Math.random() * 6, c: colors[(Math.random() * colors.length) | 0] }));
    const t0 = performance.now();
    (function frame(now) {
      ctx.clearRect(0, 0, c.width, c.height);
      bits.forEach((b) => { b.x += b.vx; b.y += b.vy; b.vy += 0.05; b.a += 0.1; ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a); ctx.fillStyle = b.c; ctx.fillRect(-b.r / 2, -b.r / 4, b.r, b.r / 2); ctx.restore(); });
      if (now - t0 < 3200) requestAnimationFrame(frame); else c.remove();
    })(t0);
  }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a; }

  document.addEventListener("keydown", (e) => {
    if (!state.lesson) return;
    if (/^[1-4]$/.test(e.key) && state.lesson.keys && !qs(".feedback") && document.activeElement.tagName !== "INPUT") state.lesson.keys(e.key);
    if (e.key === "Enter" && !e.shiftKey) {
      const next = qs("#next"); const check = qs("#checkbtn");
      if (next) { e.preventDefault(); next.click(); } else if (check && !check.disabled) { e.preventDefault(); check.click(); }
    }
  });

  // ---------- router ----------
  async function route() {
    document.documentElement.lang = I18N.lang;
    if (window.OMNIVOX_DEMO && !window.OmniEngine.hasUser) API.signOut();
    if (!API.signedIn) return viewAuth();
    try { await refresh(); } catch (e) { if (e.status === 401) { API.signOut(); return viewAuth("login"); } toast(e.message); return; }
    const page = (location.hash || "#learn").slice(1);
    if (page === "review") viewReview();
    else if (page === "league") viewLeague();
    else viewHome();
  }
  addEventListener("hashchange", () => { if (!state.lesson) route(); });
  route();
})();
