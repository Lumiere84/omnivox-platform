"""Application settings, loaded once from environment variables.

Every setting has a safe default for local development. Production refuses to
boot with the development secret (see ``Settings.validate_for_production``).
"""
from __future__ import annotations

import os
from functools import lru_cache

from pydantic import BaseModel, Field

_DEV_SECRET = "dev-only-change-me-0000000000000000000000000000"


def _env(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    return value if value not in (None, "") else default


def _env_int(name: str, default: int) -> int:
    return int(_env(name, str(default)))  # type: ignore[arg-type]


def _env_bool(name: str, default: bool) -> bool:
    return str(_env(name, str(default))).lower() in {"1", "true", "yes", "on"}


def _env_list(name: str, default: str) -> list[str]:
    return [item.strip() for item in str(_env(name, default)).split(",") if item.strip()]


class Settings(BaseModel):
    env: str = "development"
    app_name: str = "OmniVox"
    api_prefix: str = "/api/v1"
    debug: bool = False

    # Data stores
    database_url: str = "sqlite+aiosqlite:///./omnivox.db"
    database_read_url: str | None = None  # optional read replica
    db_pool_size: int = 20
    db_max_overflow: int = 20
    redis_url: str | None = "redis://localhost:6379/0"

    # Auth
    jwt_secret: str = _DEV_SECRET
    jwt_issuer: str = "omnivox"
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    password_scrypt_n: int = 2**14  # ~16 MB per hash; lowered in tests

    # HTTP
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:8000"])
    allowed_hosts: list[str] = Field(default_factory=lambda: ["*"])
    max_body_bytes: int = 64 * 1024

    # Rate limits (requests per window)
    rl_auth_per_minute: int = 10
    rl_user_per_minute: int = 300
    rl_tutor_per_hour: int = 20

    # Gamification
    hearts_max: int = 5
    heart_refill_minutes: int = 30
    xp_per_correct: int = 2
    xp_perfect_bonus: int = 5
    content_cache_seconds: int = 300

    # Integrations (all optional; features degrade gracefully)
    anthropic_api_key: str | None = None
    tutor_model: str = "claude-haiku-5-5"
    stripe_secret_key: str | None = None
    stripe_webhook_secret: str | None = None
    stripe_price_premium: str | None = None
    jobs_enabled: bool = True  # set False when no worker is deployed (free tiers)
    metrics_token: str | None = None  # if set, /metrics requires "Authorization: Bearer <token>"
    public_base_url: str = "http://localhost:8000"
    cdn_base_url: str = "https://cdn.omnivox.app"

    @property
    def is_production(self) -> bool:
        return self.env == "production"

    def validate_for_production(self) -> None:
        if not self.is_production:
            return
        problems = []
        if self.jwt_secret == _DEV_SECRET or len(self.jwt_secret) < 32:
            problems.append("JWT_SECRET must be set to a random value of 32+ characters")
        if self.database_url.startswith("sqlite"):
            problems.append("DATABASE_URL must point at PostgreSQL in production")
        if "*" in self.allowed_hosts:
            problems.append("ALLOWED_HOSTS must list real host names in production")
        if problems:
            raise RuntimeError("Unsafe production configuration: " + "; ".join(problems))


def load_settings() -> Settings:
    return Settings(
        env=_env("ENV", "development"),
        debug=_env_bool("DEBUG", False),
        database_url=_normalise_db_url(_env("DATABASE_URL", "sqlite+aiosqlite:///./omnivox.db")),
        database_read_url=_normalise_db_url(_env("DATABASE_READ_URL")),
        db_pool_size=_env_int("DB_POOL_SIZE", 20),
        db_max_overflow=_env_int("DB_MAX_OVERFLOW", 20),
        redis_url=_env("REDIS_URL", "redis://localhost:6379/0"),
        jwt_secret=_env("JWT_SECRET", _DEV_SECRET),
        access_token_minutes=_env_int("ACCESS_TOKEN_MINUTES", 15),
        refresh_token_days=_env_int("REFRESH_TOKEN_DAYS", 30),
        password_scrypt_n=_env_int("PASSWORD_SCRYPT_N", 2**14),
        cors_origins=_env_list("CORS_ORIGINS", "http://localhost:8000"),
        allowed_hosts=_env_list("ALLOWED_HOSTS", "*"),
        rl_auth_per_minute=_env_int("RL_AUTH_PER_MINUTE", 10),
        rl_user_per_minute=_env_int("RL_USER_PER_MINUTE", 300),
        rl_tutor_per_hour=_env_int("RL_TUTOR_PER_HOUR", 20),
        anthropic_api_key=_env("ANTHROPIC_API_KEY"),
        tutor_model=_env("TUTOR_MODEL", "claude-haiku-5-5"),
        stripe_secret_key=_env("STRIPE_SECRET_KEY"),
        stripe_webhook_secret=_env("STRIPE_WEBHOOK_SECRET"),
        stripe_price_premium=_env("STRIPE_PRICE_PREMIUM"),
        jobs_enabled=_env_bool("JOBS_ENABLED", True),
        metrics_token=_env("METRICS_TOKEN"),
        public_base_url=_env("PUBLIC_BASE_URL", "http://localhost:8000"),
        cdn_base_url=_env("CDN_BASE_URL", "https://cdn.omnivox.app"),
    )


def _normalise_db_url(url: str | None) -> str | None:
    """Render/Heroku hand out ``postgres://`` URLs; SQLAlchemy async needs asyncpg."""
    if url is None:
        return None
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        url = "postgresql+asyncpg://" + url[len("postgresql://"):]
    return url


@lru_cache
def get_settings() -> Settings:
    return load_settings()
