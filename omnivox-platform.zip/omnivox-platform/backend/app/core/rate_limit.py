"""Fixed-window rate limiting in Redis (atomic INCR + EXPIRE).

Fails open if Redis is unreachable: a cache outage must not take the API down.
"""
from __future__ import annotations

import logging
import time

from app.core.errors import RateLimited
from app.core.redis import get_redis

log = logging.getLogger("omnivox.ratelimit")


async def hit(bucket: str, limit: int, window_seconds: int) -> None:
    window = int(time.time() // window_seconds)
    key = f"rl:{bucket}:{window}"
    try:
        r = get_redis()
        pipe = r.pipeline(transaction=True)
        pipe.incr(key)
        pipe.expire(key, window_seconds + 5)
        count, _ = await pipe.execute()
    except Exception:  # noqa: BLE001 - fail open
        log.warning("rate limiter unavailable; allowing request", extra={"bucket": bucket})
        return
    if count > limit:
        retry = window_seconds - int(time.time() % window_seconds)
        raise RateLimited("Too many requests, please slow down",
                          headers={"Retry-After": str(max(retry, 1))})
