"""Learner progress: enrollments, attempts, the XP ledger, streak stats, review cards, tutor log."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import ForeignKey, Index, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, Timestamps, UUIDPk, utcnow


class Enrollment(Base):
    __tablename__ = "enrollments"

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    course_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"), primary_key=True)
    started_at: Mapped[datetime] = mapped_column(default=utcnow)


class LessonAttempt(UUIDPk, Base):
    __tablename__ = "lesson_attempts"
    __table_args__ = (Index("ix_attempts_user_lesson", "user_id", "lesson_id"),
                      Index("ix_attempts_user_completed", "user_id", "completed_at"))

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    lesson_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lessons.id", ondelete="CASCADE"))
    started_at: Mapped[datetime] = mapped_column(default=utcnow)
    completed_at: Mapped[datetime | None]
    correct: Mapped[int] = mapped_column(default=0)
    total: Mapped[int] = mapped_column(default=0)
    xp_earned: Mapped[int] = mapped_column(default=0)


class ExerciseAnswer(UUIDPk, Timestamps, Base):
    __tablename__ = "exercise_answers"
    __table_args__ = (UniqueConstraint("attempt_id", "exercise_id", name="uq_answers_attempt_exercise"),)

    attempt_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lesson_attempts.id", ondelete="CASCADE"))
    exercise_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exercises.id", ondelete="CASCADE"))
    given: Mapped[str] = mapped_column(String(500))
    is_correct: Mapped[bool]


class UserStats(Base):
    """One hot row per user: totals, streak and hearts. Updated under a row lock."""
    __tablename__ = "user_stats"

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    total_xp: Mapped[int] = mapped_column(default=0)
    current_streak: Mapped[int] = mapped_column(default=0)
    longest_streak: Mapped[int] = mapped_column(default=0)
    last_activity_date: Mapped[date | None]  # in the user's own time zone
    streak_freezes: Mapped[int] = mapped_column(default=0)
    hearts: Mapped[int] = mapped_column(default=5)
    hearts_updated_at: Mapped[datetime] = mapped_column(default=utcnow)
    lessons_completed: Mapped[int] = mapped_column(default=0)


class XpEvent(UUIDPk, Timestamps, Base):
    """Append-only XP ledger (source of truth; partition by month in production)."""
    __tablename__ = "xp_events"
    __table_args__ = (Index("ix_xp_events_user_created", "user_id", "created_at"),
                      UniqueConstraint("source", "ref_id", name="uq_xp_events_source_ref"))

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    amount: Mapped[int]
    source: Mapped[str] = mapped_column(String(24))  # lesson | review | bonus
    ref_id: Mapped[str] = mapped_column(String(64))  # makes every award idempotent


class ReviewCard(Base):
    """SM-2 spaced-repetition state per (user, vocab item)."""
    __tablename__ = "review_cards"
    __table_args__ = (Index("ix_review_cards_user_due", "user_id", "due_at"),)

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    vocab_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("vocab_items.id", ondelete="CASCADE"), primary_key=True)
    ease: Mapped[float] = mapped_column(default=2.5)
    interval_days: Mapped[int] = mapped_column(default=0)
    repetitions: Mapped[int] = mapped_column(default=0)
    lapses: Mapped[int] = mapped_column(default=0)
    due_at: Mapped[datetime] = mapped_column(default=utcnow)


class TutorMessage(UUIDPk, Timestamps, Base):
    __tablename__ = "tutor_messages"
    __table_args__ = (Index("ix_tutor_messages_user_created", "user_id", "created_at"),)

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    role: Mapped[str] = mapped_column(String(12))  # user | assistant
    content: Mapped[str] = mapped_column(Text)
    provider: Mapped[str] = mapped_column(String(24), default="local")
