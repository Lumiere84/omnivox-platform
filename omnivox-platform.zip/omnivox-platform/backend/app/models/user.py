from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import ForeignKey, Index, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, Timestamps, UUIDPk


class User(UUIDPk, Timestamps, Base):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(320), unique=True)  # stored lower-cased
    password_hash: Mapped[str] = mapped_column(String(255))
    display_name: Mapped[str] = mapped_column(String(60))
    native_lang: Mapped[str] = mapped_column(String(8), default="es")
    target_lang: Mapped[str] = mapped_column(String(8), default="en")
    timezone: Mapped[str] = mapped_column(String(64), default="America/Mexico_City")
    daily_goal_xp: Mapped[int] = mapped_column(default=20)
    role: Mapped[str] = mapped_column(String(16), default="learner")  # learner | admin
    plan: Mapped[str] = mapped_column(String(16), default="free")  # free | premium
    is_active: Mapped[bool] = mapped_column(default=True)
    last_active_at: Mapped[datetime | None]


class RefreshToken(UUIDPk, Timestamps, Base):
    """Opaque refresh tokens, stored hashed. Rotated on every use; reuse revokes the family."""
    __tablename__ = "refresh_tokens"
    __table_args__ = (Index("ix_refresh_tokens_user", "user_id"),)

    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    family_id: Mapped[uuid.UUID]
    expires_at: Mapped[datetime]
    revoked_at: Mapped[datetime | None]
    user_agent: Mapped[str | None] = mapped_column(String(255))
