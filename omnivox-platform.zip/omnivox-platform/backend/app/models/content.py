"""Course content: Course > Unit > Lesson > Exercise, plus vocabulary for spaced review."""
from __future__ import annotations

import uuid

from sqlalchemy import ForeignKey, Index, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, JsonType, Timestamps, UUIDPk

EXERCISE_KINDS = ("multiple_choice", "fill_blank", "translate", "listen_type", "word_bank")


class Course(UUIDPk, Timestamps, Base):
    __tablename__ = "courses"

    slug: Mapped[str] = mapped_column(String(80), unique=True)
    title: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(Text, default="")
    from_lang: Mapped[str] = mapped_column(String(8))
    to_lang: Mapped[str] = mapped_column(String(8))
    cefr_level: Mapped[str] = mapped_column(String(4), default="A1")
    is_published: Mapped[bool] = mapped_column(default=False)
    content_version: Mapped[int] = mapped_column(default=1)  # bumps invalidate caches

    units: Mapped[list[Unit]] = relationship(back_populates="course", order_by="Unit.position",
                                             cascade="all, delete-orphan")


class Unit(UUIDPk, Base):
    __tablename__ = "units"
    __table_args__ = (UniqueConstraint("course_id", "position", name="uq_units_course_position"),)

    course_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"))
    position: Mapped[int]
    title: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(Text, default="")

    course: Mapped[Course] = relationship(back_populates="units")
    lessons: Mapped[list[Lesson]] = relationship(back_populates="unit", order_by="Lesson.position",
                                                 cascade="all, delete-orphan")


class Lesson(UUIDPk, Base):
    __tablename__ = "lessons"
    __table_args__ = (UniqueConstraint("unit_id", "position", name="uq_lessons_unit_position"),)

    unit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("units.id", ondelete="CASCADE"))
    position: Mapped[int]
    title: Mapped[str] = mapped_column(String(120))
    xp_reward: Mapped[int] = mapped_column(default=10)
    is_premium: Mapped[bool] = mapped_column(default=False)

    unit: Mapped[Unit] = relationship(back_populates="lessons")
    exercises: Mapped[list[Exercise]] = relationship(back_populates="lesson", order_by="Exercise.position",
                                                     cascade="all, delete-orphan")


class Exercise(UUIDPk, Base):
    """``payload`` is safe to send to clients; ``answers`` never leaves the server."""
    __tablename__ = "exercises"
    __table_args__ = (UniqueConstraint("lesson_id", "position", name="uq_exercises_lesson_position"),)

    lesson_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lessons.id", ondelete="CASCADE"))
    position: Mapped[int]
    kind: Mapped[str] = mapped_column(String(24))
    prompt: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JsonType, default=dict)  # choices, audio_url, hint, word bank
    answers: Mapped[list] = mapped_column(JsonType, default=list)  # accepted answers
    explanation: Mapped[str] = mapped_column(Text, default="")  # shown after answering (in Spanish)
    vocab_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("vocab_items.id", ondelete="SET NULL"))

    lesson: Mapped[Lesson] = relationship(back_populates="exercises")


class VocabItem(UUIDPk, Base):
    __tablename__ = "vocab_items"
    __table_args__ = (Index("ix_vocab_course", "course_id"),
                      UniqueConstraint("course_id", "term", name="uq_vocab_course_term"))

    course_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"))
    term: Mapped[str] = mapped_column(String(120))
    translation: Mapped[str] = mapped_column(String(120))
    example: Mapped[str] = mapped_column(Text, default="")
    audio_url: Mapped[str | None] = mapped_column(String(500))
