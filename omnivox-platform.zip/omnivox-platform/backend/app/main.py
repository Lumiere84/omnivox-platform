"""OmniVox API entry point: ``uvicorn app.main:app``."""
from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from prometheus_client import Counter, Histogram
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.api.v1 import admin, auth, billing, courses, health, lessons, me, review, social
from app.core.config import get_settings
from app.core.errors import install_error_handlers
from app.core.logging import configure_logging, request_id_var
from app.core.redis import close_redis
from app.db.session import dispose_engines, init_engines

log = logging.getLogger("omnivox.http")

REQUESTS = Counter("omnivox_http_requests_total", "HTTP requests", ["method", "route", "status"])
LATENCY = Histogram("omnivox_http_request_seconds", "HTTP latency", ["method", "route"],
                    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5))

WEB_DIR = Path(__file__).resolve().parents[2] / "web"


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    settings.validate_for_production()
    init_engines()
    log.info("omnivox api started", extra={"env": settings.env})
    yield
    await close_redis()
    await dispose_engines()


def create_app() -> FastAPI:
    s = get_settings()
    configure_logging(s.debug)
    app = FastAPI(title="OmniVox API", version="1.0.0", lifespan=lifespan,
                  docs_url=None if s.is_production else "/docs", redoc_url=None,
                  openapi_url=None if s.is_production else "/openapi.json",
                  description="English for Spanish speakers: lessons, streaks, leagues, review and an AI tutor.")

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        rid = request.headers.get("x-request-id") or uuid.uuid4().hex
        if len(rid) > 64 or not rid.replace("-", "").isalnum():
            rid = uuid.uuid4().hex
        request.state.request_id = rid
        token = request_id_var.set(rid)
        length = request.headers.get("content-length")
        if length and length.isdigit() and int(length) > s.max_body_bytes:
            request_id_var.reset(token)
            return JSONResponse({"error": {"code": "payload_too_large", "message": "Request body too large",
                                           "request_id": rid}}, status_code=413)
        start = time.perf_counter()
        status = 500
        try:
            response = await call_next(request)
            status = response.status_code
        finally:
            route = request.scope.get("route")
            path = getattr(route, "path", "unmatched")
            elapsed = time.perf_counter() - start
            REQUESTS.labels(request.method, path, str(status)).inc()
            LATENCY.labels(request.method, path).observe(elapsed)
            request_id_var.reset(token)
        response.headers["X-Request-ID"] = rid
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), geolocation=(), microphone=(self)"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data: https:; media-src 'self' https:; "
            "style-src 'self' https://fonts.googleapis.com 'unsafe-inline'; font-src https://fonts.gstatic.com; "
            "script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        if s.is_production:
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        if request.url.path.startswith(s.api_prefix):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    app.add_middleware(GZipMiddleware, minimum_size=1024)
    app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_credentials=False,
                       allow_methods=["GET", "POST", "PATCH", "DELETE"],
                       allow_headers=["Authorization", "Content-Type", "X-Request-ID"])
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=s.allowed_hosts)
    install_error_handlers(app)

    app.include_router(health.router)
    for module in (auth, me, courses, lessons, review, social, billing, admin):
        app.include_router(module.router, prefix=s.api_prefix)

    if WEB_DIR.exists():  # the web client is served by the API in small deployments; by a CDN at scale
        app.mount("/", StaticFiles(directory=WEB_DIR, html=True), name="web")
    return app


app = create_app()
