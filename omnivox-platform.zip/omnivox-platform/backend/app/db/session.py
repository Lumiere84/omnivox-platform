"""Async SQLAlchemy engines: a primary (writes) and an optional read replica."""
from __future__ import annotations

from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import get_settings

_engine: AsyncEngine | None = None
_read_engine: AsyncEngine | None = None
_Session: async_sessionmaker[AsyncSession] | None = None
_ReadSession: async_sessionmaker[AsyncSession] | None = None


def _make_engine(url: str) -> AsyncEngine:
    s = get_settings()
    kwargs: dict = {"pool_pre_ping": True}
    if url.startswith("postgresql"):
        # Every query gets a 5 s ceiling so one slow query can't exhaust the pool.
        if "+asyncpg" in url:
            connect_args = {"server_settings": {"application_name": "omnivox-api", "statement_timeout": "5000"}}
        else:  # psycopg 3
            connect_args = {"options": "-c statement_timeout=5000 -c application_name=omnivox-api"}
        kwargs.update(pool_size=s.db_pool_size, max_overflow=s.db_max_overflow, pool_recycle=1800,
                      connect_args=connect_args)
    return create_async_engine(url, **kwargs)


def init_engines(url: str | None = None, read_url: str | None = None) -> None:
    global _engine, _read_engine, _Session, _ReadSession
    s = get_settings()
    _engine = _make_engine(url or s.database_url)
    _read_engine = _make_engine(read_url or s.database_read_url) if (read_url or s.database_read_url) else _engine
    _Session = async_sessionmaker(_engine, expire_on_commit=False)
    _ReadSession = async_sessionmaker(_read_engine, expire_on_commit=False)


def engine() -> AsyncEngine:
    if _engine is None:
        init_engines()
    return _engine  # type: ignore[return-value]


async def dispose_engines() -> None:
    global _engine, _read_engine
    if _read_engine is not None and _read_engine is not _engine:
        await _read_engine.dispose()
    if _engine is not None:
        await _engine.dispose()
    _engine = _read_engine = None


def session_factory() -> async_sessionmaker[AsyncSession]:
    if _Session is None:
        init_engines()
    return _Session  # type: ignore[return-value]


async def get_db() -> AsyncIterator[AsyncSession]:
    """Read-write session; commits on success, rolls back on error."""
    if _Session is None:
        init_engines()
    async with _Session() as session:  # type: ignore[misc]
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_read_db() -> AsyncIterator[AsyncSession]:
    """Read-only session routed to the replica when one is configured."""
    if _ReadSession is None:
        init_engines()
    async with _ReadSession() as session:  # type: ignore[misc]
        yield session
