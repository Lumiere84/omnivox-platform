import asyncio

from app.core.config import get_settings
from app.core.logging import configure_logging
from app.workers.queue import run_forever

if __name__ == "__main__":
    configure_logging(get_settings().debug)
    asyncio.run(run_forever())
