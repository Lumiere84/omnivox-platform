"""Tiny reliable job queue on Redis lists (LPUSH / BLMOVE with a processing list).

Swap for Celery/arq/SQS when job volume justifies it; the interface stays ``enqueue``.
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from collections.abc import Awaitable, Callable

from app.core.config import get_settings
from app.core.redis import get_redis

log = logging.getLogger("omnivox.jobs")
QUEUE, PROCESSING, DEAD = "jobs:queue", "jobs:processing", "jobs:dead"
HANDLERS: dict[str, Callable[[dict], Awaitable[None]]] = {}


def handler(name: str):
    def register(fn):
        HANDLERS[name] = fn
        return fn
    return register


async def enqueue(name: str, **payload) -> str | None:
    if not get_settings().jobs_enabled:
        return None
    job_id = uuid.uuid4().hex
    await get_redis().lpush(QUEUE, json.dumps({"id": job_id, "name": name, "payload": payload, "tries": 0}))
    return job_id


async def run_once(block_seconds: int = 1) -> bool:
    r = get_redis()
    raw = await r.blmove(QUEUE, PROCESSING, block_seconds, "RIGHT", "LEFT")
    if raw is None:
        return False
    job = json.loads(raw)
    try:
        await HANDLERS[job["name"]](job["payload"])
    except Exception:  # noqa: BLE001
        job["tries"] += 1
        log.exception("job failed", extra={"job": job["name"], "tries": job["tries"]})
        await r.lpush(DEAD if job["tries"] >= 5 else QUEUE, json.dumps(job))
    finally:
        await r.lrem(PROCESSING, 1, raw)
    return True


async def run_forever() -> None:
    from app.workers import jobs  # noqa: F401 - registers handlers
    log.info("worker started", extra={"handlers": sorted(HANDLERS)})
    while True:
        try:
            await run_once(block_seconds=5)
        except Exception:  # noqa: BLE001
            log.exception("worker loop error")
            await asyncio.sleep(1)
