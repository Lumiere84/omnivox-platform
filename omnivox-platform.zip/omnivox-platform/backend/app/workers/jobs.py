"""Background jobs. Run with: ``python -m app.workers``."""
from __future__ import annotations

import logging

from app.workers.queue import handler

log = logging.getLogger("omnivox.jobs")


@handler("welcome_email")
async def welcome_email(payload: dict) -> None:
    # Hook up SES/Postmark here. Logged (without the address) until a provider is configured.
    log.info("welcome email queued", extra={"user_id": payload.get("user_id")})


@handler("lesson_completed")
async def lesson_completed(payload: dict) -> None:
    # Fan-out point for analytics (e.g. to a warehouse), achievements and friend notifications.
    log.info("lesson completed", extra=payload)
