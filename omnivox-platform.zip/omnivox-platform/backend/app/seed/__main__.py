"""Seed the starter course and an admin: ``python -m app.seed [--admin-email you@x.com]``.

The admin password is read from the ADMIN_PASSWORD environment variable (never a CLI flag,
so it doesn't land in shell history).
"""
from __future__ import annotations

import argparse
import asyncio
import os

from sqlalchemy import select

from app.core.security import hash_password
from app.db.session import dispose_engines, engine, session_factory
from app.models import Base, User, UserStats
from app.seed.content import seed_all


async def main(create_tables: bool, admin_email: str | None) -> None:
    if create_tables:
        async with engine().begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    async with session_factory()() as db:
        created = await seed_all(db)
        print("courses created:", ", ".join(created) or "none (already present)")
        if admin_email:
            password = os.environ.get("ADMIN_PASSWORD")
            if not password:
                raise SystemExit("Set ADMIN_PASSWORD to create the admin account")
            if await db.scalar(select(User).where(User.email == admin_email.lower())) is None:
                admin = User(email=admin_email.lower(), password_hash=hash_password(password),
                             display_name="Admin", role="admin", plan="premium")
                db.add(admin)
                await db.flush()
                db.add(UserStats(user_id=admin.id))
                print("admin: created")
        await db.commit()
    await dispose_engines()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--create-tables", action="store_true", help="dev only; production uses Alembic")
    parser.add_argument("--admin-email")
    args = parser.parse_args()
    asyncio.run(main(args.create_tables, args.admin_email))
