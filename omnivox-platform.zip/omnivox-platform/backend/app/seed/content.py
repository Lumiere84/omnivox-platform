from __future__ import annotations

import json
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Course, Exercise, Lesson, Unit, VocabItem

COURSE_FILE = Path(__file__).with_name("course_en_a1.json")
COURSE_FILES = sorted(Path(__file__).parent.glob("course_*.json"))  # every language pair we ship


async def seed_all(db: AsyncSession) -> list[str]:
    return [p.stem for p in COURSE_FILES if await seed_course(db, p)]


async def seed_course(db: AsyncSession, path: Path = COURSE_FILE) -> bool:
    data = json.loads(path.read_text(encoding="utf-8"))
    if await db.scalar(select(Course.id).where(Course.slug == data["slug"])):
        return False
    course = Course(slug=data["slug"], title=data["title"], description=data["description"],
                    from_lang=data["from_lang"], to_lang=data["to_lang"], cefr_level=data["cefr_level"],
                    is_published=True)
    db.add(course)
    await db.flush()
    vocab = {}
    for v in data["vocab"]:
        item = VocabItem(course_id=course.id, term=v["term"], translation=v["translation"], example=v["example"])
        db.add(item)
        vocab[v["term"]] = item
    await db.flush()
    for u_pos, u in enumerate(data["units"], start=1):
        unit = Unit(course_id=course.id, position=u_pos, title=u["title"], description=u["description"])
        db.add(unit)
        await db.flush()
        for l_pos, l in enumerate(u["lessons"], start=1):
            lesson = Lesson(unit_id=unit.id, position=l_pos, title=l["title"], xp_reward=l["xp_reward"],
                            is_premium=l.get("is_premium", False))
            db.add(lesson)
            await db.flush()
            for e_pos, e in enumerate(l["exercises"], start=1):
                db.add(Exercise(lesson_id=lesson.id, position=e_pos, kind=e["kind"], prompt=e["prompt"],
                                payload=e["payload"], answers=e["answers"], explanation=e["explanation"],
                                vocab_id=vocab[e["vocab"]].id if e.get("vocab") else None))
    await db.flush()
    return True
