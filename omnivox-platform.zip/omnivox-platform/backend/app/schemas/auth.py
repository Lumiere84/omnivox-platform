from __future__ import annotations

import re
import uuid
from datetime import datetime
from typing import Annotated
from zoneinfo import available_timezones

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, field_validator

_TIMEZONES = available_timezones()
_EMAIL = re.compile(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$")


def _check_email(v: str) -> str:
    v = v.strip().lower()
    if len(v) > 320 or not _EMAIL.match(v):
        raise ValueError("not a valid email address")
    return v


EmailStr = Annotated[str, AfterValidator(_check_email)]


def _check_tz(v: str | None) -> str | None:
    if v is not None and v not in _TIMEZONES:
        raise ValueError("unknown time zone")
    return v


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    display_name: str = Field(min_length=1, max_length=60)
    timezone: str = "America/Mexico_City"
    native_lang: str = Field("es", pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
    target_lang: str | None = Field(None, pattern=r"^[a-z]{2}(-[A-Z]{2})?$")  # default: es->en, en->es

    _tz = field_validator("timezone")(_check_tz)

    @field_validator("password")
    @classmethod
    def strong_enough(cls, v: str) -> str:
        if v.lower() == v or not any(ch.isdigit() for ch in v):
            raise ValueError("use at least 10 characters with an upper-case letter and a number")
        return v


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=128)


class RefreshIn(BaseModel):
    refresh_token: str = Field(min_length=20, max_length=200)


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: str
    display_name: str
    native_lang: str
    target_lang: str
    timezone: str
    daily_goal_xp: int
    role: str
    plan: str
    created_at: datetime


class UserUpdate(BaseModel):
    display_name: str | None = Field(None, min_length=1, max_length=60)
    native_lang: str | None = Field(None, pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
    target_lang: str | None = Field(None, pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
    timezone: str | None = None
    daily_goal_xp: int | None = Field(None, ge=10, le=200)

    _tz = field_validator("timezone")(_check_tz)
