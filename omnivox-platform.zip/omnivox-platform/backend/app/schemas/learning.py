from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from app.models.content import EXERCISE_KINDS

ExerciseKind = Literal["multiple_choice", "fill_blank", "translate", "listen_type", "word_bank"]
assert set(ExerciseKind.__args__) == set(EXERCISE_KINDS)  # type: ignore[attr-defined]


class CourseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    slug: str
    title: str
    description: str
    from_lang: str
    to_lang: str
    cefr_level: str


class ExerciseOut(BaseModel):
    """What the client sees. Deliberately has no ``answers`` field."""
    id: uuid.UUID
    position: int
    kind: ExerciseKind
    prompt: str
    payload: dict


class LessonOut(BaseModel):
    id: uuid.UUID
    title: str
    xp_reward: int
    is_premium: bool
    course_slug: str
    exercises: list[ExerciseOut]


class AttemptOut(BaseModel):
    attempt_id: uuid.UUID
    lesson_id: uuid.UUID
    hearts: int | None  # None = unlimited (premium)


class AnswerIn(BaseModel):
    exercise_id: uuid.UUID
    answer: str = Field(max_length=500)


class AnswerOut(BaseModel):
    correct: bool
    typo: bool
    accent_missed: bool = False
    correct_answer: str
    explanation: str
    hearts: int | None


class CompleteOut(BaseModel):
    attempt_id: uuid.UUID
    correct: int
    total: int
    xp_earned: int
    total_xp: int
    streak: int
    streak_extended: bool
    daily_goal_met: bool


class StatsOut(BaseModel):
    total_xp: int
    today_xp: int
    daily_goal_xp: int
    current_streak: int
    longest_streak: int
    streak_freezes: int
    hearts: int | None
    lessons_completed: int
    last_activity_date: date | None


class ReviewCardOut(BaseModel):
    vocab_id: uuid.UUID
    term: str
    translation: str
    example: str
    audio_url: str | None
    due_at: datetime
    course: str | None = None  # course slug, so clients pick the right voice


class ReviewIn(BaseModel):
    quality: int = Field(ge=0, le=5)


class TutorIn(BaseModel):
    question: str = Field(min_length=2, max_length=800)
    exercise_id: uuid.UUID | None = None
    course: str | None = Field(None, pattern=r"^[a-z0-9-]{3,80}$")  # picks the tutor's language pair


class TutorOut(BaseModel):
    answer: str
    provider: str
    remaining_this_hour: int


# ---- admin -------------------------------------------------------------

class CourseIn(BaseModel):
    slug: str = Field(pattern=r"^[a-z0-9-]{3,80}$")
    title: str = Field(max_length=120)
    description: str = ""
    from_lang: str = "es"
    to_lang: str = "en"
    cefr_level: str = Field("A1", pattern=r"^(A1|A2|B1|B2|C1|C2)$")


class UnitIn(BaseModel):
    course_id: uuid.UUID
    position: int = Field(ge=1)
    title: str = Field(max_length=120)
    description: str = ""


class LessonIn(BaseModel):
    unit_id: uuid.UUID
    position: int = Field(ge=1)
    title: str = Field(max_length=120)
    xp_reward: int = Field(10, ge=1, le=100)
    is_premium: bool = False


class ExerciseIn(BaseModel):
    lesson_id: uuid.UUID
    position: int = Field(ge=1)
    kind: ExerciseKind
    prompt: str = Field(max_length=500)
    payload: dict = Field(default_factory=dict)
    answers: list[str] = Field(min_length=1)
    explanation: str = ""
    vocab_id: uuid.UUID | None = None


class VocabIn(BaseModel):
    course_id: uuid.UUID
    term: str = Field(max_length=120)
    translation: str = Field(max_length=120)
    example: str = ""
    audio_url: str | None = None


class CreatedOut(BaseModel):
    id: uuid.UUID
