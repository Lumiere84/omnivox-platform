"""Stripe subscriptions: Checkout for upgrades, signed webhooks for state changes."""
from __future__ import annotations

import hashlib
import hmac
import time

import httpx

from app.core.config import get_settings
from app.core.errors import AppError


def verify_stripe_signature(payload: bytes, header: str, secret: str, tolerance: int = 300) -> None:
    """Implements Stripe's documented ``Stripe-Signature`` (t=..., v1=...) HMAC-SHA256 scheme."""
    try:
        parts = dict(item.split("=", 1) for item in header.split(","))
        timestamp = int(parts["t"])
        signatures = [v for k, v in (i.split("=", 1) for i in header.split(",")) if k == "v1"]
    except (ValueError, KeyError):
        raise AppError("Malformed signature header", code="bad_signature", status_code=400) from None
    if abs(time.time() - timestamp) > tolerance:
        raise AppError("Signature timestamp outside tolerance", code="bad_signature", status_code=400)
    expected = hmac.new(secret.encode(), f"{timestamp}.".encode() + payload, hashlib.sha256).hexdigest()
    if not any(hmac.compare_digest(expected, sig) for sig in signatures):
        raise AppError("Invalid signature", code="bad_signature", status_code=400)


async def create_checkout_session(user_id: str, email: str) -> str:
    s = get_settings()
    if not (s.stripe_secret_key and s.stripe_price_premium):
        raise AppError("Payments are not configured yet", code="billing_unavailable", status_code=503)
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(
            "https://api.stripe.com/v1/checkout/sessions",
            auth=(s.stripe_secret_key, ""),
            data={
                "mode": "subscription",
                "line_items[0][price]": s.stripe_price_premium,
                "line_items[0][quantity]": "1",
                "customer_email": email,
                "client_reference_id": user_id,
                "success_url": f"{s.public_base_url}/#/premium?status=success",
                "cancel_url": f"{s.public_base_url}/#/premium?status=cancel",
            },
        )
    if resp.status_code >= 400:
        raise AppError("Payment provider error", code="billing_error", status_code=502)
    return resp.json()["url"]
