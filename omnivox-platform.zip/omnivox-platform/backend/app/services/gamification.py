"""XP, streaks and hearts: pure functions (easy to test) plus the DB/Redis glue."""
from __future__ import annotations

import uuid
from datetime import UTC, date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models import User, UserStats, XpEvent
from app.services import leaderboard


def aware(dt: datetime) -> datetime:
    """SQLite drops tz info; treat naive datetimes from the DB as UTC."""
    return dt if dt.tzinfo else dt.replace(tzinfo=UTC)


def local_today(tz_name: str, now: datetime | None = None) -> date:
    try:
        tz = ZoneInfo(tz_name)
    except (ZoneInfoNotFoundError, ValueError):
        tz = ZoneInfo("UTC")
    return (now or datetime.now(UTC)).astimezone(tz).date()


def lesson_xp(base: int, correct: int, total: int, streak: int) -> int:
    """Base reward scaled by accuracy, +perfect bonus, +10% per streak week (max +50%)."""
    s = get_settings()
    if total <= 0:
        return 0
    accuracy = correct / total
    xp = round(base * accuracy) + correct * s.xp_per_correct
    if correct == total:
        xp += s.xp_perfect_bonus
    multiplier = 1 + min(streak // 7, 5) * 0.10
    return int(round(xp * multiplier))


def advance_streak(stats: UserStats, today: date) -> bool:
    """Updates streak fields for activity on ``today``. Returns True if the streak grew."""
    last = stats.last_activity_date
    if last == today:
        return False
    if last is not None and (today - last).days == 2 and stats.streak_freezes > 0:
        stats.streak_freezes -= 1  # a freeze covers exactly one missed day
        stats.current_streak += 1
    elif last is not None and (today - last).days == 1:
        stats.current_streak += 1
    else:
        stats.current_streak = 1
    stats.longest_streak = max(stats.longest_streak, stats.current_streak)
    stats.last_activity_date = today
    return True


def effective_streak(stats: UserStats, today: date) -> int:
    """A streak shown to the user is broken if they missed yesterday (and had no freeze)."""
    if stats.last_activity_date is None:
        return 0
    gap = (today - stats.last_activity_date).days
    if gap <= 1 or (gap == 2 and stats.streak_freezes > 0):
        return stats.current_streak
    return 0


def refill_hearts(stats: UserStats, now: datetime | None = None) -> None:
    s = get_settings()
    now = now or datetime.now(UTC)
    if stats.hearts >= s.hearts_max:
        stats.hearts_updated_at = now
        return
    elapsed = now - aware(stats.hearts_updated_at)
    gained = int(elapsed / timedelta(minutes=s.heart_refill_minutes))
    if gained > 0:
        stats.hearts = min(s.hearts_max, stats.hearts + gained)
        stats.hearts_updated_at = aware(stats.hearts_updated_at) + gained * timedelta(minutes=s.heart_refill_minutes)


async def get_stats(db: AsyncSession, user_id: uuid.UUID, *, lock: bool = False) -> UserStats:
    stmt = select(UserStats).where(UserStats.user_id == user_id)
    if lock:
        stmt = stmt.with_for_update()
    stats = (await db.execute(stmt)).scalar_one_or_none()
    if stats is None:
        stats = UserStats(user_id=user_id, hearts=get_settings().hearts_max, total_xp=0, current_streak=0,
                          longest_streak=0, streak_freezes=0, lessons_completed=0,
                          hearts_updated_at=datetime.now(UTC))
        db.add(stats)
        await db.flush()
    return stats


async def award_xp(db: AsyncSession, user: User, stats: UserStats, amount: int, source: str, ref_id: str,
                   course_slug: str | None = None) -> bool:
    """Writes the ledger row (idempotent on source+ref_id), bumps totals and leaderboards."""
    if amount <= 0:
        return False
    try:
        async with db.begin_nested():
            db.add(XpEvent(user_id=user.id, amount=amount, source=source, ref_id=ref_id))
    except IntegrityError:
        return False  # already awarded
    stats.total_xp += amount
    await leaderboard.add_xp(user, amount, course_slug)
    return True
