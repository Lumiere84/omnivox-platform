"""AI tutor. Uses Claude when ANTHROPIC_API_KEY is set; otherwise a built-in explainer.

The tutor always explains in the learner's own language (the course's ``from_lang``) with short
examples in the language being learned, and stays on the topic of the course.
"""
from __future__ import annotations

import logging

import httpx

from app.core.config import get_settings
from app.services.grading import normalise, strip_accents

log = logging.getLogger("omnivox.tutor")

SYSTEM_PROMPTS = {
    "es": (
        "Eres OmniVox, un tutor de inglés amable para hispanohablantes de nivel {level}. "
        "Responde en español claro y breve (máximo 120 palabras), con 1 a 3 ejemplos en inglés. "
        "Si te preguntan algo que no sea aprender inglés, redirige con amabilidad a la lección. "
        "Nunca pidas datos personales."
    ),
    "en": (
        "You are OmniVox, a friendly Latin American Spanish tutor for English speakers at level {level}. "
        "Answer in clear, short English (120 words max) with 1 to 3 Spanish examples and their translations. "
        "If asked about anything other than learning Spanish, kindly steer back to the lesson. "
        "Never ask for personal information."
    ),
}
SYSTEM_PROMPT = SYSTEM_PROMPTS["es"]  # backwards-compatible name

_LOCAL_TIPS = {
    "do does": "Usa *does* con he/she/it y *do* con I/you/we/they. Ej.: *She does her homework.* / *They do yoga.*",
    "am is are": "*I am*, *you/we/they are*, *he/she/it is*. Ej.: *I am happy. She is a teacher.*",
    "a an": "Usa *an* antes de sonido vocal: *an apple, an hour*; y *a* antes de consonante: *a book, a university*.",
    "in on at": "*at* para horas (at 5 pm), *on* para días (on Monday), *in* para meses y años (in May, in 2026).",
    "past": "Pasado simple: verbos regulares + *-ed* (*worked*, *played*); irregulares se memorizan (*go → went*).",
}


# Tips for English speakers learning Spanish (explained in English).
_LOCAL_TIPS_EN = {
    "ser estar": "*Ser* = what something IS (identity, origin, job, time): *Soy de Texas. Es doctora.* "
                 "*Estar* = how or where it is right now (feelings, location): *Estoy cansado. Está en casa.*",
    "por para": "*Para* points to a goal or destination: *Es para ti.* *Salgo para México.* "
                "*Por* is the route, cause or exchange: *Gracias por todo.* *Caminamos por el parque.*",
    "tu usted formal": "*Tú* is informal (friends, family, kids). *Usted* is polite (strangers, elders, work). "
                       "Usted uses the he/she verb form: *¿Cómo está usted?* vs *¿Cómo estás?*",
    "gender el la masculine feminine": "Every noun is masculine or feminine. Most -o words are masculine (*el libro*), "
                                       "most -a words feminine (*la casa*). Learn each noun with its article.",
    "accent accents tilde": "Accents mark stress (*está*) or tell words apart (*tú* you vs *tu* your). "
                            "OmniVox accepts answers without accents but shows you where they go.",
    "gustar like": "*Gustar* works backwards: *Me gusta el café* = coffee pleases me. "
                   "Plural things: *Me gustan los tacos.*",
    "past preterite pasado": "Preterite of -ar verbs: *hablé, hablaste, habló, hablamos, hablaron*. "
                             "Common irregulars: *ir → fui*, *ser → fui*, *ver → vi*, *hacer → hice*.",
}


def _local_answer(question: str, explain_in: str = "es") -> str:
    q = f" {strip_accents(normalise(question))} "
    tips = _LOCAL_TIPS_EN if explain_in == "en" else _LOCAL_TIPS
    for keys, tip in tips.items():
        if any(f" {k} " in q for k in keys.split()):
            return tip
    if explain_in == "en":
        return ("Good question! Write it with an example sentence in Spanish and I'll walk you through it. "
                "Meanwhile, practice your words in *Review*.")
    return ("¡Buena pregunta! Escríbela con un ejemplo en inglés y te explico paso a paso. "
            "Mientras tanto, repasa tus palabras en la sección *Repaso*.")


async def ask(question: str, level: str = "A1", context: str | None = None,
              explain_in: str = "es") -> tuple[str, str]:
    """Returns (answer, provider)."""
    s = get_settings()
    explain_in = "en" if explain_in.startswith("en") else "es"
    if not s.anthropic_api_key:
        return _local_answer(question, explain_in), "local"
    label = ("Lesson context", "Question") if explain_in == "en" else ("Contexto de la lección", "Pregunta")
    user_text = question if not context else f"{label[0]}: {context}\n\n{label[1]}: {question}"
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": s.anthropic_api_key, "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": s.tutor_model, "max_tokens": 400,
                      "system": SYSTEM_PROMPTS[explain_in].format(level=level),
                      "messages": [{"role": "user", "content": user_text}]},
            )
            resp.raise_for_status()
            data = resp.json()
            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            return text.strip() or _local_answer(question, explain_in), "claude"
    except Exception:  # noqa: BLE001 - never fail the lesson because the tutor is down
        log.warning("tutor provider failed; using local fallback")
        return _local_answer(question, explain_in), "local"
