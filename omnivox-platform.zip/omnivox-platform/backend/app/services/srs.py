"""SM-2 spaced repetition (the SuperMemo 2 algorithm used by Anki)."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.models import ReviewCard


def schedule(card: ReviewCard, quality: int, now: datetime | None = None) -> ReviewCard:
    """quality: 0 (forgot) .. 5 (perfect). Below 3 resets the card."""
    if not 0 <= quality <= 5:
        raise ValueError("quality must be 0..5")
    now = now or datetime.now(UTC)
    if quality < 3:
        card.repetitions = 0
        card.interval_days = 1
        card.lapses += 1
    else:
        if card.repetitions == 0:
            card.interval_days = 1
        elif card.repetitions == 1:
            card.interval_days = 6
        else:
            card.interval_days = max(1, round(card.interval_days * card.ease))
        card.repetitions += 1
    card.ease = max(1.3, card.ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)))
    card.due_at = now + timedelta(days=card.interval_days)
    return card
