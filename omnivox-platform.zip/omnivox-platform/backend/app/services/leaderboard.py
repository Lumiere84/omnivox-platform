"""Weekly leagues in Redis sorted sets: O(log N) updates, O(log N + K) top-K reads.

Keys roll over automatically each ISO week and expire after 5 weeks, so there is
no reset job. Leaderboards are a derived view; the XP ledger stays the source of truth.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime

from app.core.redis import get_redis

log = logging.getLogger("omnivox.leaderboard")
_TTL = 5 * 7 * 24 * 3600


def week_id(now: datetime | None = None) -> str:
    y, w, _ = (now or datetime.now(UTC)).isocalendar()
    return f"{y}-W{w:02d}"


def _key(scope: str, week: str) -> str:
    return f"lb:{scope}:{week}"


async def add_xp(user, amount: int, course_slug: str | None) -> None:
    week = week_id()
    try:
        r = get_redis()
        pipe = r.pipeline(transaction=False)
        for scope in ("global", f"course:{course_slug}" if course_slug else None):
            if scope is None:
                continue
            pipe.zincrby(_key(scope, week), amount, str(user.id))
            pipe.expire(_key(scope, week), _TTL)
        pipe.hset("lb:names", str(user.id), user.display_name)
        await pipe.execute()
    except Exception:  # noqa: BLE001 - leaderboard is best-effort
        log.warning("leaderboard update failed", extra={"user_id": str(user.id)})


async def top(scope: str, limit: int = 20, user_id: str | None = None) -> dict:
    week = week_id()
    r = get_redis()
    key = _key(scope, week)
    rows = await r.zrevrange(key, 0, limit - 1, withscores=True)
    names = await r.hmget("lb:names", [uid for uid, _ in rows]) if rows else []
    entries = [{"rank": i + 1, "user_id": uid, "display_name": names[i] or "Learner", "xp": int(score)}
               for i, (uid, score) in enumerate(rows)]
    me = None
    if user_id:
        rank = await r.zrevrank(key, user_id)
        score = await r.zscore(key, user_id)
        if rank is not None:
            me = {"rank": rank + 1, "xp": int(score or 0)}
    return {"week": week, "scope": scope, "entries": entries, "me": me}
