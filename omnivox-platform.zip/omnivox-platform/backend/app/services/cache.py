"""Read-through JSON cache for hot, rarely-changing content (course paths, lessons).

Keys include the course ``content_version``; publishing new content bumps the
version, so stale entries are simply never read again and age out by TTL.
"""
from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable
from typing import Any

from app.core.config import get_settings
from app.core.redis import get_redis

log = logging.getLogger("omnivox.cache")


async def cached(key: str, loader: Callable[[], Awaitable[Any]], ttl: int | None = None) -> Any:
    ttl = ttl or get_settings().content_cache_seconds
    try:
        hit = await get_redis().get(key)
        if hit is not None:
            return json.loads(hit)
    except Exception:  # noqa: BLE001
        log.warning("cache read failed", extra={"key": key})
    value = await loader()
    try:
        await get_redis().set(key, json.dumps(value, default=str), ex=ttl)
    except Exception:  # noqa: BLE001
        log.warning("cache write failed", extra={"key": key})
    return value
