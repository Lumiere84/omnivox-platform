"""Server-side answer grading. Answers never reach the client, so grading cannot be cheated."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from difflib import SequenceMatcher

_CONTRACTIONS = {
    "i'm": "i am", "you're": "you are", "he's": "he is", "she's": "she is", "it's": "it is",
    "we're": "we are", "they're": "they are", "don't": "do not", "doesn't": "does not",
    "isn't": "is not", "aren't": "are not", "can't": "cannot", "won't": "will not",
    "i've": "i have", "let's": "let us", "what's": "what is", "that's": "that is",
}
_PUNCT = re.compile(r"[^\w\s']", re.UNICODE)
_SPACES = re.compile(r"\s+")


def normalise(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "").lower()
    text = text.replace("’", "'").replace("‘", "'").replace("`", "'")
    text = _PUNCT.sub(" ", text)
    text = _SPACES.sub(" ", text).strip()
    return " ".join(_CONTRACTIONS.get(word, word) for word in text.split(" "))


def strip_accents(text: str) -> str:
    """'está' -> 'esta', 'niño' -> 'nino'. Used to forgive missing accents, not to ignore them."""
    return "".join(ch for ch in unicodedata.normalize("NFD", text) if unicodedata.category(ch) != "Mn")


_FREE_TEXT = {"translate", "listen_type", "fill_blank"}


@dataclass(frozen=True)
class GradeResult:
    correct: bool
    typo: bool = False
    best_answer: str = ""
    accent_missed: bool = False


def grade(kind: str, given: str, accepted: list[str]) -> GradeResult:
    """Exact match after normalisation; free-text kinds also forgive one small typo."""
    if not accepted:
        return GradeResult(False)
    norm_given = normalise(given)
    normalised = [(normalise(a), a) for a in accepted]
    for norm, original in normalised:
        if norm_given == norm:
            return GradeResult(True, False, original)
    if kind not in _FREE_TEXT:  # choices must match exactly ("hablé" vs "hable" is the point)
        return GradeResult(False, False, accepted[0])
    # Accepted with a nudge: the learner typed "esta" for "está" or "senor" for "señor".
    bare_given = strip_accents(norm_given)
    for norm, original in normalised:
        if bare_given == strip_accents(norm):
            return GradeResult(True, True, original, accent_missed=True)
    if len(norm_given) >= 5:
        for norm, original in normalised:
            if len(norm) >= 5 and SequenceMatcher(None, norm_given, norm).ratio() >= 0.9:
                return GradeResult(True, True, original)
    return GradeResult(False, False, accepted[0])
