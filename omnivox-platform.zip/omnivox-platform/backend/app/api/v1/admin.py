"""Content studio API for the curriculum team. Every write bumps the course content_version."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, status
from sqlalchemy import func, select

from app.api.deps import DB, AdminUser
from app.core.errors import Conflict, NotFound
from app.models import Course, Exercise, Lesson, LessonAttempt, Unit, User, VocabItem
from app.schemas.learning import CourseIn, CreatedOut, ExerciseIn, LessonIn, UnitIn, VocabIn

router = APIRouter(prefix="/admin", tags=["admin"])


async def _bump(db, course_id: uuid.UUID) -> None:
    course = await db.get(Course, course_id)
    if course is None:
        raise NotFound("Course not found")
    course.content_version += 1


async def _course_of_unit(db, unit_id) -> uuid.UUID:
    unit = await db.get(Unit, unit_id)
    if unit is None:
        raise NotFound("Unit not found")
    return unit.course_id


@router.post("/courses", response_model=CreatedOut, status_code=status.HTTP_201_CREATED)
async def create_course(body: CourseIn, _: AdminUser, db: DB):
    if await db.scalar(select(Course.id).where(Course.slug == body.slug)):
        raise Conflict("Slug already used")
    course = Course(**body.model_dump())
    db.add(course)
    await db.flush()
    return CreatedOut(id=course.id)


@router.post("/courses/{course_id}/publish", status_code=status.HTTP_204_NO_CONTENT)
async def publish_course(course_id: uuid.UUID, _: AdminUser, db: DB, published: bool = True):
    course = await db.get(Course, course_id)
    if course is None:
        raise NotFound("Course not found")
    course.is_published = published
    course.content_version += 1


@router.post("/units", response_model=CreatedOut, status_code=status.HTTP_201_CREATED)
async def create_unit(body: UnitIn, _: AdminUser, db: DB):
    await _bump(db, body.course_id)
    unit = Unit(**body.model_dump())
    db.add(unit)
    await db.flush()
    return CreatedOut(id=unit.id)


@router.post("/lessons", response_model=CreatedOut, status_code=status.HTTP_201_CREATED)
async def create_lesson(body: LessonIn, _: AdminUser, db: DB):
    await _bump(db, await _course_of_unit(db, body.unit_id))
    lesson = Lesson(**body.model_dump())
    db.add(lesson)
    await db.flush()
    return CreatedOut(id=lesson.id)


@router.post("/exercises", response_model=CreatedOut, status_code=status.HTTP_201_CREATED)
async def create_exercise(body: ExerciseIn, _: AdminUser, db: DB):
    lesson = await db.get(Lesson, body.lesson_id)
    if lesson is None:
        raise NotFound("Lesson not found")
    await _bump(db, await _course_of_unit(db, lesson.unit_id))
    exercise = Exercise(**body.model_dump())
    db.add(exercise)
    await db.flush()
    return CreatedOut(id=exercise.id)


@router.post("/vocab", response_model=CreatedOut, status_code=status.HTTP_201_CREATED)
async def create_vocab(body: VocabIn, _: AdminUser, db: DB):
    await _bump(db, body.course_id)
    item = VocabItem(**body.model_dump())
    db.add(item)
    await db.flush()
    return CreatedOut(id=item.id)


@router.get("/metrics")
async def business_metrics(_: AdminUser, db: DB):
    return {
        "users": await db.scalar(select(func.count()).select_from(User)),
        "premium_users": await db.scalar(select(func.count()).select_from(User).where(User.plan == "premium")),
        "lessons_completed": await db.scalar(select(func.count()).select_from(LessonAttempt)
                                             .where(LessonAttempt.completed_at.is_not(None))),
    }
