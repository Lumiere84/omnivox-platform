from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Request, status
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError

from app.api.deps import DB, CurrentUser, client_ip
from app.core import rate_limit
from app.core.config import get_settings
from app.core.errors import Conflict, Unauthorized
from app.core.security import (
    create_access_token,
    dummy_verify,
    hash_password,
    hash_token,
    needs_rehash,
    new_refresh_token,
    verify_password,
)
from app.models import RefreshToken, User, UserStats
from app.schemas.auth import LoginIn, RefreshIn, RegisterIn, TokenOut
from app.services.gamification import aware
from app.workers.queue import enqueue

router = APIRouter(prefix="/auth", tags=["auth"])


async def _issue(db, user: User, request: Request, family: uuid.UUID | None = None) -> TokenOut:
    s = get_settings()
    access, ttl = create_access_token(user.id, user.role, user.plan)
    token, digest = new_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=digest, family_id=family or uuid.uuid4(),
                        expires_at=datetime.now(UTC) + timedelta(days=s.refresh_token_days),
                        user_agent=(request.headers.get("user-agent") or "")[:255]))
    return TokenOut(access_token=access, refresh_token=token, expires_in=ttl)


@router.post("/register", response_model=TokenOut, status_code=status.HTTP_201_CREATED)
async def register(body: RegisterIn, request: Request, db: DB):
    await rate_limit.hit(f"auth:{client_ip(request)}", get_settings().rl_auth_per_minute, 60)
    exists = await db.scalar(select(User.id).where(User.email == body.email))
    if exists:
        raise Conflict("An account with this email already exists", code="email_taken")
    user = User(email=body.email, password_hash=hash_password(body.password), display_name=body.display_name,
                timezone=body.timezone, native_lang=body.native_lang,
                target_lang=body.target_lang or ("en" if body.native_lang.startswith("es") else "es"))
    db.add(user)
    try:
        await db.flush()
    except IntegrityError:
        raise Conflict("An account with this email already exists", code="email_taken") from None
    s = get_settings()
    db.add(UserStats(user_id=user.id, hearts=s.hearts_max, total_xp=0, current_streak=0, longest_streak=0,
                     streak_freezes=0, lessons_completed=0, hearts_updated_at=datetime.now(UTC)))
    tokens = await _issue(db, user, request)
    try:
        await enqueue("welcome_email", user_id=str(user.id))
    except Exception:  # noqa: BLE001 - email is nice-to-have
        pass
    return tokens


@router.post("/login", response_model=TokenOut)
async def login(body: LoginIn, request: Request, db: DB):
    await rate_limit.hit(f"auth:{client_ip(request)}", get_settings().rl_auth_per_minute, 60)
    await rate_limit.hit(f"login:{hash_token(body.email)[:24]}", 20, 3600)  # slows credential stuffing per account
    user = await db.scalar(select(User).where(User.email == body.email))
    if user is None:
        dummy_verify(body.password)
        raise Unauthorized("Email or password is incorrect", code="bad_credentials")
    if not verify_password(body.password, user.password_hash) or not user.is_active:
        raise Unauthorized("Email or password is incorrect", code="bad_credentials")
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    user.last_active_at = datetime.now(UTC)
    return await _issue(db, user, request)


@router.post("/refresh", response_model=TokenOut)
async def refresh(body: RefreshIn, request: Request, db: DB):
    await rate_limit.hit(f"refresh:{client_ip(request)}", 60, 60)
    row = await db.scalar(select(RefreshToken).where(RefreshToken.token_hash == hash_token(body.refresh_token))
                          .with_for_update())
    now = datetime.now(UTC)
    if row is None:
        raise Unauthorized("Session expired, please sign in again", code="invalid_refresh")
    if row.revoked_at is not None:
        # Reuse of a rotated token = likely theft. Kill the whole session family.
        await db.execute(update(RefreshToken).where(RefreshToken.family_id == row.family_id,
                                                    RefreshToken.revoked_at.is_(None)).values(revoked_at=now))
        await db.commit()
        raise Unauthorized("Session expired, please sign in again", code="invalid_refresh")
    if aware(row.expires_at) < now:
        raise Unauthorized("Session expired, please sign in again", code="invalid_refresh")
    user = await db.get(User, row.user_id)
    if user is None or not user.is_active:
        raise Unauthorized("Account not available")
    row.revoked_at = now
    return await _issue(db, user, request, family=row.family_id)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(body: RefreshIn, user: CurrentUser, db: DB):
    row = await db.scalar(select(RefreshToken).where(RefreshToken.token_hash == hash_token(body.refresh_token),
                                                     RefreshToken.user_id == user.id))
    if row is not None:
        await db.execute(update(RefreshToken).where(RefreshToken.family_id == row.family_id,
                                                    RefreshToken.revoked_at.is_(None))
                         .values(revoked_at=datetime.now(UTC)))
