from __future__ import annotations

from fastapi import APIRouter, status
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.api.deps import DB, CurrentUser, ReadDB
from app.core.errors import NotFound
from app.models import Course, Enrollment, LessonAttempt, Unit
from app.schemas.learning import CourseOut
from app.services.cache import cached

router = APIRouter(prefix="/courses", tags=["courses"])


async def _published(db, slug: str) -> Course:
    course = await db.scalar(select(Course).where(Course.slug == slug, Course.is_published.is_(True)))
    if course is None:
        raise NotFound("Course not found")
    return course


@router.get("", response_model=list[CourseOut])
async def list_courses(db: ReadDB):
    async def load():
        rows = (await db.scalars(select(Course).where(Course.is_published.is_(True)).order_by(Course.title))).all()
        return [CourseOut.model_validate(c).model_dump(mode="json") for c in rows]
    return await cached("courses:published", load, ttl=60)


@router.post("/{slug}/enroll", status_code=status.HTTP_204_NO_CONTENT)
async def enroll(slug: str, user: CurrentUser, db: DB):
    course = await _published(db, slug)
    if await db.get(Enrollment, (user.id, course.id)) is None:
        db.add(Enrollment(user_id=user.id, course_id=course.id))


@router.get("/{slug}/path")
async def course_path(slug: str, user: CurrentUser, db: ReadDB):
    """The learning path: units and lessons with each lesson's state for this learner.

    The content skeleton is cached per course version; the learner overlay is one indexed query.
    """
    course = await _published(db, slug)

    async def load_skeleton():
        units = (await db.scalars(select(Unit).where(Unit.course_id == course.id).order_by(Unit.position)
                                  .options(selectinload(Unit.lessons)))).all()
        return [{"id": str(u.id), "position": u.position, "title": u.title, "description": u.description,
                 "lessons": [{"id": str(l.id), "position": l.position, "title": l.title,
                              "xp_reward": l.xp_reward, "is_premium": l.is_premium} for l in u.lessons]}
                for u in units]

    skeleton = await cached(f"path:{course.id}:v{course.content_version}", load_skeleton)
    done = set((await db.scalars(select(LessonAttempt.lesson_id).where(
        LessonAttempt.user_id == user.id, LessonAttempt.completed_at.is_not(None)).distinct())).all())
    done = {str(x) for x in done}

    unlocked_next = True  # the first not-yet-completed lesson is the only unlocked one
    for unit in skeleton:
        for lesson in unit["lessons"]:
            if lesson["id"] in done:
                lesson["state"] = "completed"
            elif lesson["is_premium"] and user.plan != "premium":
                lesson["state"] = "premium"  # bonus content; never blocks the free path
            elif unlocked_next:
                lesson["state"] = "available"
                unlocked_next = False
            else:
                lesson["state"] = "locked"
    return {"course": CourseOut.model_validate(course).model_dump(mode="json"), "units": skeleton}
