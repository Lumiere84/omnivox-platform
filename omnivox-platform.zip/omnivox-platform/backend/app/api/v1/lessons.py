"""The core learning loop: open lesson -> start attempt -> answer exercises -> complete."""
from __future__ import annotations

import uuid
from datetime import UTC, datetime, time
from zoneinfo import ZoneInfo

from fastapi import APIRouter, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from app.api.deps import DB, CurrentUser
from app.core.errors import AppError, Conflict, Forbidden, NotFound
from app.models import Course, Exercise, ExerciseAnswer, Lesson, LessonAttempt, ReviewCard, Unit, XpEvent
from app.schemas.learning import AnswerIn, AnswerOut, AttemptOut, CompleteOut, ExerciseOut, LessonOut
from app.services import gamification as g
from app.services.cache import cached
from app.services.grading import grade
from app.workers.queue import enqueue

router = APIRouter(tags=["lessons"])


async def _lesson_with_course(db, lesson_id: uuid.UUID) -> tuple[Lesson, Course]:
    row = (await db.execute(select(Lesson, Course).join(Unit, Lesson.unit_id == Unit.id)
                            .join(Course, Unit.course_id == Course.id).where(Lesson.id == lesson_id))).first()
    if row is None or not row[1].is_published:
        raise NotFound("Lesson not found")
    return row[0], row[1]


def _check_access(user, lesson: Lesson) -> None:
    if lesson.is_premium and user.plan != "premium":
        raise Forbidden("This lesson is part of OmniVox Premium", code="premium_required")


@router.get("/lessons/{lesson_id}", response_model=LessonOut)
async def get_lesson(lesson_id: uuid.UUID, user: CurrentUser, db: DB):
    lesson, course = await _lesson_with_course(db, lesson_id)
    _check_access(user, lesson)

    async def load():
        exercises = (await db.scalars(select(Exercise).where(Exercise.lesson_id == lesson.id)
                                      .order_by(Exercise.position))).all()
        return LessonOut(id=lesson.id, title=lesson.title, xp_reward=lesson.xp_reward,
                         is_premium=lesson.is_premium, course_slug=course.slug,
                         exercises=[ExerciseOut(id=e.id, position=e.position, kind=e.kind, prompt=e.prompt,
                                                payload=e.payload) for e in exercises]).model_dump(mode="json")
    return await cached(f"lesson:{lesson.id}:v{course.content_version}", load)


@router.post("/lessons/{lesson_id}/attempts", response_model=AttemptOut, status_code=status.HTTP_201_CREATED)
async def start_attempt(lesson_id: uuid.UUID, user: CurrentUser, db: DB):
    lesson, _ = await _lesson_with_course(db, lesson_id)
    _check_access(user, lesson)
    stats = await g.get_stats(db, user.id)
    g.refill_hearts(stats)
    if user.plan != "premium" and stats.hearts <= 0:
        raise Forbidden("You are out of hearts. They refill over time, or go Premium for unlimited.",
                        code="out_of_hearts")
    attempt = LessonAttempt(user_id=user.id, lesson_id=lesson.id, correct=0, total=0, xp_earned=0)
    db.add(attempt)
    await db.flush()
    return AttemptOut(attempt_id=attempt.id, lesson_id=lesson.id,
                      hearts=None if user.plan == "premium" else stats.hearts)


async def _own_attempt(db, user, attempt_id: uuid.UUID, *, lock: bool = False) -> LessonAttempt:
    attempt = await db.get(LessonAttempt, attempt_id, with_for_update=lock, populate_existing=lock)
    if attempt is None or attempt.user_id != user.id:
        raise NotFound("Attempt not found")
    return attempt


@router.post("/attempts/{attempt_id}/answers", response_model=AnswerOut)
async def submit_answer(attempt_id: uuid.UUID, body: AnswerIn, user: CurrentUser, db: DB):
    attempt = await _own_attempt(db, user, attempt_id)
    if attempt.completed_at is not None:
        raise Conflict("This attempt is already finished", code="attempt_closed")
    exercise = await db.get(Exercise, body.exercise_id)
    if exercise is None or exercise.lesson_id != attempt.lesson_id:
        raise NotFound("Exercise not found in this lesson")

    result = grade(exercise.kind, body.answer, exercise.answers)
    try:
        async with db.begin_nested():
            db.add(ExerciseAnswer(attempt_id=attempt.id, exercise_id=exercise.id, given=body.answer[:500],
                                  is_correct=result.correct))
    except IntegrityError:
        raise Conflict("You already answered this exercise", code="already_answered") from None

    stats = await g.get_stats(db, user.id, lock=True)
    g.refill_hearts(stats)
    if not result.correct and user.plan != "premium":
        stats.hearts = max(0, stats.hearts - 1)
    if exercise.vocab_id is not None and result.correct:  # words you get right join your review deck
        if await db.get(ReviewCard, (user.id, exercise.vocab_id)) is None:
            db.add(ReviewCard(user_id=user.id, vocab_id=exercise.vocab_id))
    return AnswerOut(correct=result.correct, typo=result.typo, accent_missed=result.accent_missed,
                     correct_answer=result.best_answer,
                     explanation=exercise.explanation,
                     hearts=None if user.plan == "premium" else stats.hearts)


@router.post("/attempts/{attempt_id}/complete", response_model=CompleteOut)
async def complete_attempt(attempt_id: uuid.UUID, user: CurrentUser, db: DB):
    """Idempotent: completing twice returns the same result and never double-awards XP."""
    attempt = await _own_attempt(db, user, attempt_id, lock=True)  # serialises double-taps
    stats = await g.get_stats(db, user.id, lock=True)
    today = g.local_today(user.timezone)

    if attempt.completed_at is None:
        lesson, course = await _lesson_with_course(db, attempt.lesson_id)
        total = await db.scalar(select(func.count()).select_from(Exercise).where(Exercise.lesson_id == lesson.id))
        answers = (await db.scalars(select(ExerciseAnswer).where(ExerciseAnswer.attempt_id == attempt.id))).all()
        if len(answers) < (total or 0):
            raise AppError("Answer every exercise before finishing", code="lesson_incomplete", status_code=409)
        correct = sum(1 for a in answers if a.is_correct)
        extended = g.advance_streak(stats, today)
        xp = g.lesson_xp(lesson.xp_reward, correct, total or 0, stats.current_streak)
        attempt.correct, attempt.total, attempt.completed_at = correct, total or 0, datetime.now(UTC)
        if await g.award_xp(db, user, stats, xp, "lesson", str(attempt.id), course.slug):
            attempt.xp_earned = xp
        stats.lessons_completed += 1
        user.last_active_at = attempt.completed_at
        try:
            await enqueue("lesson_completed", user_id=str(user.id), lesson_id=str(lesson.id), xp=xp,
                          correct=correct, total=total)
        except Exception:  # noqa: BLE001
            pass
    else:
        extended = False

    start_local = datetime.combine(today, time.min, tzinfo=ZoneInfo(user.timezone)).astimezone(UTC)
    today_xp = await db.scalar(select(func.coalesce(func.sum(XpEvent.amount), 0))
                               .where(XpEvent.user_id == user.id, XpEvent.created_at >= start_local))
    return CompleteOut(attempt_id=attempt.id, correct=attempt.correct, total=attempt.total,
                       xp_earned=attempt.xp_earned, total_xp=stats.total_xp, streak=stats.current_streak,
                       streak_extended=extended, daily_goal_met=int(today_xp or 0) >= user.daily_goal_xp)
