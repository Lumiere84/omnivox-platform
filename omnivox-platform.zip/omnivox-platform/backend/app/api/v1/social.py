from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Query
from sqlalchemy import func, select

from app.api.deps import DB, CurrentUser
from app.core import rate_limit
from app.core.config import get_settings
from app.core.errors import NotFound
from app.models import Course, Exercise, Lesson, TutorMessage, Unit
from app.schemas.learning import TutorIn, TutorOut
from app.services import leaderboard, tutor

router = APIRouter(tags=["social"])


@router.get("/leaderboard/weekly")
async def weekly_leaderboard(user: CurrentUser, course: str | None = Query(None, pattern=r"^[a-z0-9-]{3,80}$"),
                             limit: int = Query(20, ge=1, le=100)):
    scope = f"course:{course}" if course else "global"
    return await leaderboard.top(scope, limit, str(user.id))


@router.post("/tutor/ask", response_model=TutorOut)
async def ask_tutor(body: TutorIn, user: CurrentUser, db: DB):
    s = get_settings()
    hourly = s.rl_tutor_per_hour * (5 if user.plan == "premium" else 1)
    await rate_limit.hit(f"tutor:{user.id}", hourly, 3600)
    context, course = None, None
    if body.exercise_id:
        row = (await db.execute(select(Exercise, Course).join(Lesson, Exercise.lesson_id == Lesson.id)
                                .join(Unit, Lesson.unit_id == Unit.id).join(Course, Unit.course_id == Course.id)
                                .where(Exercise.id == body.exercise_id))).first()
        if row is None:
            raise NotFound("Exercise not found")
        exercise, course = row
        context = f"{exercise.prompt} (answer: {', '.join(exercise.answers[:2])})"
    elif body.course:
        course = await db.scalar(select(Course).where(Course.slug == body.course))
    explain_in = course.from_lang if course else user.native_lang
    level = course.cefr_level if course else "A1"
    answer, provider = await tutor.ask(body.question, level=level, context=context, explain_in=explain_in)
    db.add(TutorMessage(user_id=user.id, role="user", content=body.question, provider=provider))
    db.add(TutorMessage(user_id=user.id, role="assistant", content=answer, provider=provider))
    used = await db.scalar(select(func.count()).select_from(TutorMessage).where(
        TutorMessage.user_id == user.id, TutorMessage.role == "user",
        TutorMessage.created_at >= datetime.now(UTC) - timedelta(hours=1)))
    return TutorOut(answer=answer, provider=provider, remaining_this_hour=max(0, hourly - int(used or 0) - 1))
