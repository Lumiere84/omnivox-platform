from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.api.deps import DB, CurrentUser
from app.core.config import get_settings
from app.core.errors import AppError
from app.models import ProcessedWebhook, Subscription, User
from app.services.billing import create_checkout_session, verify_stripe_signature

router = APIRouter(prefix="/billing", tags=["billing"])

_ACTIVE = {"active", "trialing"}


@router.post("/checkout")
async def checkout(user: CurrentUser):
    return {"url": await create_checkout_session(str(user.id), user.email)}


@router.get("/subscription")
async def my_subscription(user: CurrentUser, db: DB):
    sub = await db.scalar(select(Subscription).where(Subscription.user_id == user.id))
    return {"plan": user.plan, "status": sub.status if sub else None,
            "current_period_end": sub.current_period_end if sub else None}


@router.post("/webhook", include_in_schema=False)
async def stripe_webhook(request: Request, db: DB):
    secret = get_settings().stripe_webhook_secret
    if not secret:
        raise AppError("Webhooks not configured", code="billing_unavailable", status_code=503)
    payload = await request.body()
    verify_stripe_signature(payload, request.headers.get("stripe-signature", ""), secret)
    event = json.loads(payload)
    try:
        async with db.begin_nested():
            db.add(ProcessedWebhook(event_id=str(event["id"])))
    except IntegrityError:
        return {"received": True, "duplicate": True}

    obj = event.get("data", {}).get("object", {})
    etype = event.get("type", "")
    if etype == "checkout.session.completed" and obj.get("client_reference_id"):
        user = await db.get(User, uuid.UUID(obj["client_reference_id"]))
        if user:
            sub = await db.scalar(select(Subscription).where(Subscription.user_id == user.id))
            if sub is None:
                sub = Subscription(user_id=user.id)
                db.add(sub)
            sub.customer_ref, sub.subscription_ref, sub.status = obj.get("customer"), obj.get("subscription"), "active"
            user.plan = "premium"
    elif etype in {"customer.subscription.updated", "customer.subscription.deleted"}:
        sub = await db.scalar(select(Subscription).where(Subscription.subscription_ref == obj.get("id")))
        if sub:
            sub.status = obj.get("status", "canceled")
            if obj.get("current_period_end"):
                sub.current_period_end = datetime.fromtimestamp(obj["current_period_end"], UTC)
            user = await db.get(User, sub.user_id)
            if user:
                user.plan = "premium" if sub.status in _ACTIVE else "free"
    return {"received": True}
