from __future__ import annotations

import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Query
from sqlalchemy import select

from app.api.deps import DB, CurrentUser
from app.core.errors import NotFound
from app.models import Course, ReviewCard, VocabItem
from app.schemas.learning import ReviewCardOut, ReviewIn
from app.services import gamification as g
from app.services.srs import schedule

router = APIRouter(prefix="/review", tags=["review"])


@router.get("/due", response_model=list[ReviewCardOut])
async def due_cards(user: CurrentUser, db: DB, limit: int = Query(20, ge=1, le=50)):
    rows = (await db.execute(
        select(ReviewCard, VocabItem, Course.slug).join(VocabItem, VocabItem.id == ReviewCard.vocab_id)
        .join(Course, Course.id == VocabItem.course_id)
        .where(ReviewCard.user_id == user.id, ReviewCard.due_at <= datetime.now(UTC))
        .order_by(ReviewCard.due_at).limit(limit))).all()
    return [ReviewCardOut(vocab_id=v.id, term=v.term, translation=v.translation, example=v.example,
                          audio_url=v.audio_url, due_at=c.due_at, course=slug) for c, v, slug in rows]


@router.post("/{vocab_id}")
async def review_card(vocab_id: uuid.UUID, body: ReviewIn, user: CurrentUser, db: DB):
    card = await db.get(ReviewCard, (user.id, vocab_id), with_for_update=True)
    if card is None:
        raise NotFound("Card not in your review deck")
    now = datetime.now(UTC)
    if g.aware(card.due_at) > now:
        return {"due_at": card.due_at, "interval_days": card.interval_days, "xp_earned": 0}
    schedule(card, body.quality, now)
    stats = await g.get_stats(db, user.id, lock=True)
    g.advance_streak(stats, g.local_today(user.timezone))
    # One XP per due review; ref ties the award to this exact scheduling step.
    ref = f"{vocab_id}:{card.repetitions}:{card.lapses}:{now.date()}"
    earned = 1 if await g.award_xp(db, user, stats, 1, "review", ref) else 0
    return {"due_at": card.due_at, "interval_days": card.interval_days, "xp_earned": earned}
