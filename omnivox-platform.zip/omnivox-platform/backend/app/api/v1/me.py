from __future__ import annotations

from datetime import UTC, datetime, time
from zoneinfo import ZoneInfo

from fastapi import APIRouter, status
from sqlalchemy import delete, func, select

from app.api.deps import DB, CurrentUser
from app.models import User, XpEvent
from app.schemas.auth import UserOut, UserUpdate
from app.schemas.learning import StatsOut
from app.services.gamification import effective_streak, get_stats, local_today, refill_hearts

router = APIRouter(prefix="/me", tags=["me"])


@router.get("", response_model=UserOut)
async def read_me(user: CurrentUser):
    return user


@router.patch("", response_model=UserOut)
async def update_me(body: UserUpdate, user: CurrentUser):
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    return user


@router.get("/stats", response_model=StatsOut)
async def my_stats(user: CurrentUser, db: DB):
    stats = await get_stats(db, user.id)
    refill_hearts(stats)
    today = local_today(user.timezone)
    start_local = datetime.combine(today, time.min, tzinfo=ZoneInfo(user.timezone))
    today_xp = await db.scalar(select(func.coalesce(func.sum(XpEvent.amount), 0)).where(
        XpEvent.user_id == user.id, XpEvent.created_at >= start_local.astimezone(UTC)))
    return StatsOut(
        total_xp=stats.total_xp, today_xp=int(today_xp or 0), daily_goal_xp=user.daily_goal_xp,
        current_streak=effective_streak(stats, today), longest_streak=stats.longest_streak,
        streak_freezes=stats.streak_freezes, hearts=None if user.plan == "premium" else stats.hearts,
        lessons_completed=stats.lessons_completed, last_activity_date=stats.last_activity_date,
    )


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
async def delete_me(user: CurrentUser, db: DB):
    """Right to erasure (GDPR / LGPD / CCPA): cascades remove all personal rows."""
    await db.execute(delete(User).where(User.id == user.id))
