from __future__ import annotations

import hmac

from fastapi import APIRouter, Request, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from sqlalchemy import text

from app.core.config import get_settings
from app.core.errors import Unauthorized
from app.core.redis import get_redis
from app.db.session import engine

router = APIRouter(tags=["ops"])


@router.get("/healthz", include_in_schema=False)
async def healthz():
    """Liveness: the process is up."""
    return {"status": "ok"}


@router.get("/readyz", include_in_schema=False)
async def readyz(response: Response):
    """Readiness: dependencies reachable. Load balancers stop routing here if not."""
    checks = {}
    try:
        async with engine().connect() as conn:
            await conn.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception:  # noqa: BLE001
        checks["database"] = "down"
    try:
        await get_redis().ping()
        checks["redis"] = "ok"
    except Exception:  # noqa: BLE001
        checks["redis"] = "degraded"  # API still works without Redis (fails open)
    if checks["database"] != "ok":
        response.status_code = 503
    return {"status": "ok" if response.status_code != 503 else "unavailable", "checks": checks}


@router.get("/metrics", include_in_schema=False)
async def metrics(request: Request):
    token = get_settings().metrics_token
    if token and not hmac.compare_digest(request.headers.get("authorization", ""), f"Bearer {token}"):
        raise Unauthorized("Metrics token required")
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
