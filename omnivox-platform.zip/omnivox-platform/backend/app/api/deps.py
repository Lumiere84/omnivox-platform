from __future__ import annotations

import uuid
from typing import Annotated

import jwt
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core import rate_limit
from app.core.config import get_settings
from app.core.errors import Forbidden, Unauthorized
from app.core.security import decode_access_token
from app.db.session import get_db, get_read_db
from app.models import User

_bearer = HTTPBearer(auto_error=False)

DB = Annotated[AsyncSession, Depends(get_db)]
ReadDB = Annotated[AsyncSession, Depends(get_read_db)]


def client_ip(request: Request) -> str:
    # Behind a trusted load balancer, uvicorn's --proxy-headers sets request.client from X-Forwarded-For.
    return request.client.host if request.client else "unknown"


async def current_user(request: Request, db: DB,
                       creds: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> User:
    if creds is None or creds.scheme.lower() != "bearer":
        raise Unauthorized("Sign in required", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = decode_access_token(creds.credentials)
        user_id = uuid.UUID(payload["sub"])
    except (jwt.PyJWTError, ValueError, KeyError):
        raise Unauthorized("Session expired or invalid", headers={"WWW-Authenticate": "Bearer"}) from None
    user = await db.get(User, user_id)
    if user is None or not user.is_active:
        raise Unauthorized("Account not available")
    await rate_limit.hit(f"user:{user.id}", get_settings().rl_user_per_minute, 60)
    request.state.user_id = str(user.id)
    return user


CurrentUser = Annotated[User, Depends(current_user)]


async def admin_user(user: CurrentUser) -> User:
    if user.role != "admin":
        raise Forbidden("Admins only")
    return user


AdminUser = Annotated[User, Depends(admin_user)]
