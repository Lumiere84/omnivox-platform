import json
from pathlib import Path

import pytest

pytestmark = pytest.mark.asyncio
API = "/api/v1"
SLUG = "ingles-esencial-a1"
COURSE = json.loads((Path(__file__).parents[1] / "app/seed/course_en_a1.json").read_text(encoding="utf-8"))


def _answers_for(lesson_title):
    for unit in COURSE["units"]:
        for lesson in unit["lessons"]:
            if lesson["title"] == lesson_title:
                return [e["answers"][0] for e in lesson["exercises"]]
    raise KeyError(lesson_title)


async def _path(client, u):
    r = await client.get(f"{API}/courses/{SLUG}/path", headers=u["h"])
    assert r.status_code == 200, r.text
    return r.json()


async def _play(client, u, lesson_id, answers):
    lesson = (await client.get(f"{API}/lessons/{lesson_id}", headers=u["h"])).json()
    attempt = (await client.post(f"{API}/lessons/{lesson_id}/attempts", headers=u["h"])).json()
    results = []
    for ex, ans in zip(lesson["exercises"], answers, strict=False):
        r = await client.post(f"{API}/attempts/{attempt['attempt_id']}/answers", headers=u["h"],
                              json={"exercise_id": ex["id"], "answer": ans})
        assert r.status_code == 200, r.text
        results.append(r.json())
    return lesson, attempt, results


async def test_courses_and_path_states(client, make_user):
    u = await make_user()
    courses = (await client.get(f"{API}/courses")).json()
    assert {c["slug"] for c in courses} == {SLUG, "spanish-essentials-a1"}
    path = await _path(client, u)
    states = [l["state"] for unit in path["units"] for l in unit["lessons"]]
    assert states[0] == "available" and states[1] == "locked" and "premium" in states


async def test_answers_never_leak(client, make_user):
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    body = (await client.get(f"{API}/lessons/{first['id']}", headers=u["h"])).text
    assert "answers" not in body and "explanation" not in body


async def test_full_lesson_awards_xp_streak_and_unlocks_next(client, make_user):
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    _, attempt, results = await _play(client, u, first["id"], _answers_for("Hola y adiós"))
    assert all(r["correct"] for r in results)
    done = (await client.post(f"{API}/attempts/{attempt['attempt_id']}/complete", headers=u["h"])).json()
    assert done["correct"] == done["total"] == 5
    assert done["xp_earned"] == 10 + 5 * 2 + 5  # base + per-correct + perfect bonus
    assert done["streak"] == 1 and done["streak_extended"] is True and done["daily_goal_met"] is True

    again = (await client.post(f"{API}/attempts/{attempt['attempt_id']}/complete", headers=u["h"])).json()
    assert again["xp_earned"] == done["xp_earned"] and again["total_xp"] == done["total_xp"]  # idempotent

    states = [l["state"] for l in (await _path(client, u))["units"][0]["lessons"]]
    assert states[:2] == ["completed", "available"]

    stats = (await client.get(f"{API}/me/stats", headers=u["h"])).json()
    assert stats["total_xp"] == 25 and stats["today_xp"] == 25 and stats["lessons_completed"] == 1

    board = (await client.get(f"{API}/leaderboard/weekly?course={SLUG}", headers=u["h"])).json()
    assert board["entries"][0]["xp"] == 25 and board["me"]["rank"] == 1


async def test_wrong_answers_cost_hearts_and_typos_forgiven(client, make_user):
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    answers = ["Thanks", "good mornin", "Goodbye, see you tomorrow.", "Thank you very much", "You’re welcome!"]
    _, attempt, results = await _play(client, u, first["id"], answers)
    assert results[0]["correct"] is False and results[0]["correct_answer"] == "Hello"
    assert results[0]["hearts"] == 4
    assert results[1]["correct"] is True and results[1]["typo"] is True
    assert results[4]["correct"] is True  # curly apostrophe + punctuation normalised
    done = (await client.post(f"{API}/attempts/{attempt['attempt_id']}/complete", headers=u["h"])).json()
    assert done["correct"] == 4 and done["xp_earned"] < 25


async def test_cannot_finish_early_or_answer_twice(client, make_user):
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    lesson, attempt, _ = await _play(client, u, first["id"], ["Hello"])
    r = await client.post(f"{API}/attempts/{attempt['attempt_id']}/complete", headers=u["h"])
    assert r.status_code == 409 and r.json()["error"]["code"] == "lesson_incomplete"
    r = await client.post(f"{API}/attempts/{attempt['attempt_id']}/answers", headers=u["h"],
                          json={"exercise_id": lesson["exercises"][0]["id"], "answer": "Hello"})
    assert r.status_code == 409


async def test_other_users_attempt_is_invisible(client, make_user):
    a, b = await make_user("A"), await make_user("B")
    first = (await _path(client, a))["units"][0]["lessons"][0]
    attempt = (await client.post(f"{API}/lessons/{first['id']}/attempts", headers=a["h"])).json()
    r = await client.post(f"{API}/attempts/{attempt['attempt_id']}/complete", headers=b["h"])
    assert r.status_code == 404


async def test_premium_lesson_blocked_for_free(client, make_user):
    u = await make_user()
    premium = [l for unit in (await _path(client, u))["units"] for l in unit["lessons"] if l["is_premium"]][0]
    r = await client.get(f"{API}/lessons/{premium['id']}", headers=u["h"])
    assert r.status_code == 403 and r.json()["error"]["code"] == "premium_required"


async def test_out_of_hearts(client, make_user):
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    _, attempt, results = await _play(client, u, first["id"], ["x1", "x2", "x3", "x4", "x5"])
    assert results[-1]["hearts"] == 0
    r = await client.post(f"{API}/lessons/{first['id']}/attempts", headers=u["h"])
    assert r.status_code == 403 and r.json()["error"]["code"] == "out_of_hearts"


async def test_review_deck_from_correct_vocab(client, make_user):
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    _, attempt, _ = await _play(client, u, first["id"], _answers_for("Hola y adiós"))
    due = (await client.get(f"{API}/review/due", headers=u["h"])).json()
    assert {c["term"] for c in due} == {"hello", "good morning", "goodbye", "thank you"}
    r = (await client.post(f"{API}/review/{due[0]['vocab_id']}", headers=u["h"], json={"quality": 5})).json()
    assert r["interval_days"] == 1 and r["xp_earned"] == 1
    assert len((await client.get(f"{API}/review/due", headers=u["h"])).json()) == 3


async def test_tutor_local_fallback(client, make_user):
    u = await make_user()
    r = await client.post(f"{API}/tutor/ask", headers=u["h"], json={"question": "¿Cuándo uso do o does?"})
    assert r.status_code == 200
    assert r.json()["provider"] == "local" and "does" in r.json()["answer"]


async def test_concurrent_complete_is_safe(client, make_user):
    """Double-tapping 'finish' from two devices must award XP exactly once."""
    import asyncio
    u = await make_user()
    first = (await _path(client, u))["units"][0]["lessons"][0]
    _, attempt, _ = await _play(client, u, first["id"], _answers_for("Hola y adiós"))
    url = f"{API}/attempts/{attempt['attempt_id']}/complete"
    results = await asyncio.gather(*[client.post(url, headers=u["h"]) for _ in range(5)])
    assert all(r.status_code == 200 for r in results)
    stats = (await client.get(f"{API}/me/stats", headers=u["h"])).json()
    assert stats["total_xp"] == 25 and stats["lessons_completed"] == 1


ES = json.loads((Path(__file__).parents[1] / "app/seed/course_es_a1.json").read_text(encoding="utf-8"))
ES_SLUG = "spanish-essentials-a1"


async def test_english_speaker_learns_spanish(client, make_user):
    u = await make_user("Mike", tz="America/Chicago", native="en")
    me = (await client.get(f"{API}/me", headers=u["h"])).json()
    assert me["native_lang"] == "en" and me["target_lang"] == "es"
    course = next(c for c in (await client.get(f"{API}/courses")).json() if c["slug"] == ES_SLUG)
    assert course["from_lang"] == "en" and course["to_lang"] == "es"

    path = (await client.get(f"{API}/courses/{ES_SLUG}/path", headers=u["h"])).json()
    first = path["units"][0]["lessons"][0]
    assert first["title"] == "Hola and adiós" and first["state"] == "available"

    exercises = ES["units"][0]["lessons"][0]["exercises"]
    answers = [e["answers"][0] for e in exercises]
    answers[1] = "buenos dias"            # missing accent: accepted, flagged
    answers[2] = "adios hasta manana"     # missing accent and tilde: accepted, flagged
    _, attempt, results = await _play(client, u, first["id"], answers)
    assert all(r["correct"] for r in results)
    assert results[1]["accent_missed"] and results[1]["correct_answer"] == "Buenos días"
    assert results[2]["accent_missed"] and not results[0]["accent_missed"]
    done = (await client.post(f"{API}/attempts/{attempt['attempt_id']}/complete", headers=u["h"])).json()
    assert done["correct"] == 5 and done["xp_earned"] == 25

    # Leagues are per course: the Spanish learner tops the Spanish league only.
    board = (await client.get(f"{API}/leaderboard/weekly?course={ES_SLUG}", headers=u["h"])).json()
    assert board["me"]["rank"] == 1
    other = (await client.get(f"{API}/leaderboard/weekly?course={SLUG}", headers=u["h"])).json()
    assert other["me"] is None

    due = {c["term"] for c in (await client.get(f"{API}/review/due", headers=u["h"])).json()}
    assert due == {"hola", "buenos días", "adiós", "gracias"}


async def test_tutor_explains_in_learners_language(client, make_user):
    u = await make_user("Mike", native="en")
    r = (await client.post(f"{API}/tutor/ask", headers=u["h"],
                           json={"question": "When do I use ser or estar?", "course": ES_SLUG})).json()
    assert "identity" in r["answer"] and "Estoy" in r["answer"]
    r = (await client.post(f"{API}/tutor/ask", headers=u["h"], json={"question": "tu or usted?"})).json()
    assert "polite" in r["answer"]  # falls back to the learner's native language (English)
