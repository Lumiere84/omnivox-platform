import os
import tempfile

_tmp = tempfile.mkdtemp()
os.environ.update({
    "ENV": "test",
    # Default: SQLite + fakeredis (no services needed). CI also runs against real
    # PostgreSQL and Redis by setting TEST_DATABASE_URL / TEST_REDIS_URL.
    "DATABASE_URL": os.getenv("TEST_DATABASE_URL", f"sqlite+aiosqlite:///{_tmp}/test.db"),
    "PASSWORD_SCRYPT_N": "1024",
    "JWT_SECRET": "test-secret-for-unit-tests-only-0123456789",
    "RL_AUTH_PER_MINUTE": "1000",
})

import fakeredis  # noqa: E402
import httpx  # noqa: E402
import pytest  # noqa: E402
import pytest_asyncio  # noqa: E402

from app.core.redis import set_redis  # noqa: E402
from app.db import session as db_session  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Base  # noqa: E402
from app.seed.content import seed_all  # noqa: E402


@pytest_asyncio.fixture
async def client():
    if os.getenv("TEST_REDIS_URL"):
        import redis.asyncio as aioredis
        real = aioredis.from_url(os.environ["TEST_REDIS_URL"], decode_responses=True)
        await real.flushdb()
        set_redis(real)
    else:
        set_redis(fakeredis.FakeAsyncRedis(decode_responses=True))
    db_session.init_engines()
    async with db_session.engine().begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    async with db_session.session_factory()() as db:
        await seed_all(db)
        await db.commit()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    await db_session.dispose_engines()
    set_redis(None)


_counter = {"n": 0}


@pytest_asyncio.fixture
async def make_user(client):
    async def _make(name="Ana", password="Secreto123", tz="America/Mexico_City", native="es"):
        _counter["n"] += 1
        email = f"user{_counter['n']}@example.com"
        r = await client.post("/api/v1/auth/register", json={"email": email, "password": password,
                                                             "display_name": name, "timezone": tz,
                                                             "native_lang": native})
        assert r.status_code == 201, r.text
        tokens = r.json()
        return {"email": email, "password": password, "tokens": tokens,
                "h": {"Authorization": f"Bearer {tokens['access_token']}"}}
    return _make


@pytest.fixture
def anyio_backend():
    return "asyncio"
