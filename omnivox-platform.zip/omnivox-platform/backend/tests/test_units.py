import hashlib
import hmac
import json
import time
from datetime import UTC, date, datetime, timedelta

import pytest

from app.models import ReviewCard, UserStats
from app.services import gamification as g
from app.services.grading import grade, normalise
from app.services.srs import schedule

API = "/api/v1"


def test_normalise():
    assert normalise("  I’m   FROM Mexico!! ") == "i am from mexico"
    assert normalise("¿Dónde está el banco?") == "dónde está el banco"


def test_grade_kinds():
    assert grade("multiple_choice", "hello", ["Hello"]).correct
    assert not grade("multiple_choice", "helo", ["Hello"]).correct  # no typo tolerance for choices
    assert grade("translate", "I am from mexco", ["I am from Mexico"]).typo
    assert not grade("translate", "I am from Spain", ["I am from Mexico"]).correct


def test_accents_forgiven_only_when_typed():
    r = grade("translate", "Ella esta feliz", ["Ella está feliz"])
    assert r.correct and r.accent_missed and r.best_answer == "Ella está feliz"
    assert grade("fill_blank", "senor", ["señor"]).accent_missed
    assert not grade("multiple_choice", "hable", ["hablé"]).correct  # choices must be exact
    plain = grade("translate", "¿Qué tal?", ["Qué tal"])
    assert plain.correct and not plain.typo


def _stats(**kw):
    base = dict(user_id=None, total_xp=0, current_streak=0, longest_streak=0, last_activity_date=None,
                streak_freezes=0, hearts=5, hearts_updated_at=datetime.now(UTC), lessons_completed=0)
    base.update(kw)
    return UserStats(**base)


def test_streak_rules():
    s = _stats()
    d = date(2026, 10, 1)
    assert g.advance_streak(s, d) and s.current_streak == 1
    assert not g.advance_streak(s, d)  # same day doesn't double count
    g.advance_streak(s, d + timedelta(days=1))
    assert s.current_streak == 2
    g.advance_streak(s, d + timedelta(days=4))  # missed days -> reset
    assert s.current_streak == 1 and s.longest_streak == 2

    f = _stats(current_streak=5, longest_streak=5, last_activity_date=d, streak_freezes=1)
    g.advance_streak(f, d + timedelta(days=2))  # one missed day covered by a freeze
    assert f.current_streak == 6 and f.streak_freezes == 0


def test_streak_respects_user_timezone():
    utc_late = datetime(2026, 10, 2, 3, 30, tzinfo=UTC)  # still Oct 1 in Mexico City
    assert g.local_today("America/Mexico_City", utc_late) == date(2026, 10, 1)
    assert g.local_today("Europe/Madrid", utc_late) == date(2026, 10, 2)


def test_hearts_refill():
    s = _stats(hearts=1, hearts_updated_at=datetime.now(UTC) - timedelta(minutes=65))
    g.refill_hearts(s)
    assert s.hearts == 3


def test_streak_multiplier():
    assert g.lesson_xp(10, 5, 5, 0) == 25
    assert g.lesson_xp(10, 5, 5, 14) == 30  # 2 streak weeks -> +20%
    assert g.lesson_xp(10, 0, 5, 0) == 0


def test_sm2():
    c = ReviewCard(ease=2.5, interval_days=0, repetitions=0, lapses=0)
    now = datetime(2026, 1, 1, tzinfo=UTC)
    schedule(c, 5, now)
    schedule(c, 5, now)
    assert c.interval_days == 6
    schedule(c, 4, now)
    assert c.interval_days >= 15
    schedule(c, 1, now)
    assert c.interval_days == 1 and c.lapses == 1 and c.ease >= 1.3


def _signed(payload: bytes, secret: str, ts: int | None = None) -> str:
    ts = ts or int(time.time())
    sig = hmac.new(secret.encode(), f"{ts}.".encode() + payload, hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"


@pytest.mark.asyncio
async def test_stripe_webhook_upgrade_idempotent_and_signed(client, make_user, monkeypatch):
    from app.core.config import get_settings
    monkeypatch.setattr(get_settings(), "stripe_webhook_secret", "whsec_test")
    u = await make_user()
    me = (await client.get(f"{API}/me", headers=u["h"])).json()
    event = {"id": "evt_1", "type": "checkout.session.completed",
             "data": {"object": {"client_reference_id": me["id"], "customer": "cus_1", "subscription": "sub_1"}}}
    payload = json.dumps(event).encode()

    bad = await client.post(f"{API}/billing/webhook", content=payload, headers={"stripe-signature": "t=1,v1=00"})
    assert bad.status_code == 400

    for _ in range(2):
        r = await client.post(f"{API}/billing/webhook", content=payload,
                              headers={"stripe-signature": _signed(payload, "whsec_test")})
        assert r.status_code == 200
    assert r.json().get("duplicate") is True
    assert (await client.get(f"{API}/me", headers=u["h"])).json()["plan"] == "premium"
    stats = (await client.get(f"{API}/me/stats", headers=u["h"])).json()
    assert stats["hearts"] is None  # unlimited

    cancel = {"id": "evt_2", "type": "customer.subscription.deleted",
              "data": {"object": {"id": "sub_1", "status": "canceled"}}}
    p2 = json.dumps(cancel).encode()
    await client.post(f"{API}/billing/webhook", content=p2, headers={"stripe-signature": _signed(p2, "whsec_test")})
    assert (await client.get(f"{API}/me", headers=u["h"])).json()["plan"] == "free"


@pytest.mark.asyncio
async def test_admin_rbac_and_cache_invalidation(client, make_user):
    from sqlalchemy import update

    from app.db.session import session_factory
    from app.models import User

    learner, admin = await make_user("L"), await make_user("Boss")
    async with session_factory()() as db:
        await db.execute(update(User).where(User.email == admin["email"]).values(role="admin"))
        await db.commit()

    body = {"slug": "ingles-a2", "title": "Inglés A2", "cefr_level": "A2"}
    assert (await client.post(f"{API}/admin/courses", headers=learner["h"], json=body)).status_code == 403
    r = await client.post(f"{API}/admin/courses", headers=admin["h"], json=body)
    assert r.status_code == 201
    course_id = r.json()["id"]
    unit = (await client.post(f"{API}/admin/units", headers=admin["h"],
                              json={"course_id": course_id, "position": 1, "title": "Viajes"})).json()
    lesson = (await client.post(f"{API}/admin/lessons", headers=admin["h"],
                                json={"unit_id": unit["id"], "position": 1, "title": "En el aeropuerto"})).json()
    r = await client.post(f"{API}/admin/exercises", headers=admin["h"], json={
        "lesson_id": lesson["id"], "position": 1, "kind": "translate", "prompt": "Traduce: pasaporte",
        "answers": ["passport"]})
    assert r.status_code == 201
    assert (await client.post(f"{API}/admin/courses/{course_id}/publish", headers=admin["h"])).status_code == 204
    path = (await client.get(f"{API}/courses/ingles-a2/path", headers=learner["h"])).json()
    assert path["units"][0]["lessons"][0]["title"] == "En el aeropuerto"
    metrics = (await client.get(f"{API}/admin/metrics", headers=admin["h"])).json()
    assert metrics["users"] == 2


@pytest.mark.asyncio
async def test_readyz_and_metrics(client):
    r = await client.get("/readyz")
    assert r.status_code == 200 and r.json()["checks"]["database"] == "ok"
    assert "omnivox_http_requests_total" in (await client.get("/metrics")).text


@pytest.mark.asyncio
async def test_job_queue_runs_and_dead_letters(client):
    from app.core.redis import get_redis
    from app.workers import queue

    seen = []

    @queue.handler("t_ok")
    async def _ok(payload):
        seen.append(payload["n"])

    @queue.handler("t_bad")
    async def _bad(payload):
        raise RuntimeError("boom")

    await queue.enqueue("t_ok", n=1)
    assert await queue.run_once() and seen == [1]
    await queue.enqueue("t_bad")
    for _ in range(5):
        await queue.run_once()
    assert await get_redis().llen(queue.DEAD) == 1
    assert await get_redis().llen(queue.PROCESSING) == 0
