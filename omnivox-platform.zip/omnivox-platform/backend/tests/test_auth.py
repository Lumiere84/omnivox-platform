import pytest

pytestmark = pytest.mark.asyncio
API = "/api/v1"


async def test_register_login_me(client, make_user):
    u = await make_user()
    r = await client.get(f"{API}/me", headers=u["h"])
    assert r.status_code == 200
    assert r.json()["email"] == u["email"] and r.json()["plan"] == "free"
    assert "password_hash" not in r.json()

    r = await client.post(f"{API}/auth/login", json={"email": u["email"].upper(), "password": u["password"]})
    assert r.status_code == 200 and r.json()["access_token"]


async def test_duplicate_email_and_weak_password(client, make_user):
    u = await make_user()
    r = await client.post(f"{API}/auth/register", json={"email": u["email"], "password": "Secreto123",
                                                        "display_name": "X"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "email_taken"
    r = await client.post(f"{API}/auth/register", json={"email": "new@example.com", "password": "short",
                                                        "display_name": "X"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "validation_error"


async def test_bad_login_same_message(client, make_user):
    u = await make_user()
    a = await client.post(f"{API}/auth/login", json={"email": u["email"], "password": "WrongPass999"})
    b = await client.post(f"{API}/auth/login", json={"email": "nobody@example.com", "password": "WrongPass999"})
    assert a.status_code == b.status_code == 401
    assert a.json()["error"]["message"] == b.json()["error"]["message"]


async def test_refresh_rotation_and_reuse_detection(client, make_user):
    u = await make_user()
    old = u["tokens"]["refresh_token"]
    r = await client.post(f"{API}/auth/refresh", json={"refresh_token": old})
    assert r.status_code == 200
    new = r.json()["refresh_token"]
    assert new != old
    # Re-using the rotated token is treated as theft: it fails and kills the new one too.
    assert (await client.post(f"{API}/auth/refresh", json={"refresh_token": old})).status_code == 401
    assert (await client.post(f"{API}/auth/refresh", json={"refresh_token": new})).status_code == 401


async def test_protected_routes_need_token(client):
    r = await client.get(f"{API}/me")
    assert r.status_code == 401 and r.json()["error"]["code"] == "unauthorized"
    r = await client.get(f"{API}/me", headers={"Authorization": "Bearer not-a-jwt"})
    assert r.status_code == 401


async def test_security_headers_and_request_id(client):
    r = await client.get("/healthz", headers={"X-Request-ID": "abc-123"})
    assert r.headers["x-request-id"] == "abc-123"
    assert r.headers["x-content-type-options"] == "nosniff"
    assert "frame-ancestors 'none'" in r.headers["content-security-policy"]


async def test_auth_rate_limit(client, monkeypatch):
    from app.core import rate_limit
    from app.core.config import get_settings
    monkeypatch.setattr(get_settings(), "rl_auth_per_minute", 3)
    monkeypatch.setattr(rate_limit.time, "time", lambda: 1_700_000_010.0)  # stay inside one window
    body = {"email": "x@example.com", "password": "Nope12345"}
    codes = [(await client.post(f"{API}/auth/login", json=body)).status_code for _ in range(5)]
    assert codes[:3] == [401, 401, 401] and codes[3] == 429


async def test_delete_account(client, make_user):
    u = await make_user()
    assert (await client.delete(f"{API}/me", headers=u["h"])).status_code == 204
    assert (await client.get(f"{API}/me", headers=u["h"])).status_code == 401
