"""Bundle the web client + in-browser engine + course into ONE self-contained demo page.

    python tools/build_demo.py            -> dist/omnivox-live-demo.html

The demo runs the exact same app.js as production; window.OMNIVOX_DEMO routes its API
calls to engine.js instead of the FastAPI server.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
COURSES = [ROOT / "backend/app/seed/course_en_a1.json", ROOT / "backend/app/seed/course_es_a1.json"]
OUT = ROOT / "dist/omnivox-live-demo.html"


def main() -> None:
    css = (WEB / "css/app.css").read_text(encoding="utf-8")
    scripts = "\n".join((WEB / f"js/{name}.js").read_text(encoding="utf-8")
                        for name in ("i18n", "api", "engine", "app"))
    courses = "[" + ",".join(p.read_text(encoding="utf-8") for p in COURSES).replace("</", "<\\/") + "]"
    page = f"""<title>OmniVox Live Demo</title>
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="description" content="Interactive OmniVox demo: English lessons for Spanish speakers.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Figtree:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap">
<style>
{css}
</style>
<div id="app" class="app"></div>
<script>
window.OMNIVOX_DEMO = true;
window.OMNIVOX_COURSES = {courses};
</script>
<script>
{scripts}
</script>
"""
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(page, encoding="utf-8")
    print(f"wrote {OUT} ({OUT.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
